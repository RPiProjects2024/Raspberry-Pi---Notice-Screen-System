#!/bin/bash

# Installs / removes software as part of system updates.

# Global Variables:
	CMDACTIONS="-y" 			# Default CMD line action for automation.


# Install APPLICATION NAME.
	echo "+ Installing APPLICATION NAME..."
	sudo apt-get $CMDACTIONS install APPLICATIONNAME > /dev/null
	APPLICATIONINSTALLRESULT=$?
if [ $APPLICATIONINSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} APPLICATIONNAME Installed. (Command output: $APPLICATIONINSTALLRESULT)"
else
	echo -e "!${RED} [FAIL]${WHITE} APPLICATIONNAME failed to install (package may already be installed?) (0x00001)."
fi