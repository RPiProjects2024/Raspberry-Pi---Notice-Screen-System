#!/bin/bash

# Performs automatic updates for security and compliance.
# Use the Management System to make changes to schedules.

# Global Variables:

CURRENTHOSTIP=$(hostname -I)						# Used for event logging.
CURRENTHOSTNAME=$(hostname)							# Used for event logging.
AUTOUPDATELOGFILELOC="/home/pi/AutoUpdate.log"		# Location of the scripted automatic update log.
CURRENTDATE=$(date +"%m-%d-%Y")						# The current date for stamping log backups.
CURRENTTIME=$(date +%H:%M:%S)						# The current time for stamping log backups.

# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi $AUTOUPDATELOGFILELOC &> /dev/null

# Perform update:
	sudo apt-get update && sudo apt-get upgrade -y
UPDATEOUTCOME=$?
if [ $UPDATEOUTCOME -eq 0 ]; then
	# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(AUTO-UPDATER):" "Installed updates successfully. A reboot is advised." >> /home/pi/RPNSMS/eventlog.log
else
	# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(AUTO-UPDATER):" "Failed to install updates!" >> /home/pi/RPNSMS/eventlog.log

fi

# Create folder where backup logs are stored, even if the folder already exists.
	sudo mkdir /home/pi/Event_Logs_Backups &> /dev/null

# Copy the current log folder:
	sudo cp /home/pi/RPNSMS/eventlog.log /home/pi/Event_Logs_Backups


# Rename the copied log file:
	sudo mv /home/pi/Event_Logs_Backups/eventlog.log /home/pi/Event_Logs_Backups/LOG_BACKUP:" ""$CURRENTDATE"" ""[$CURRENTTIME]".logbak