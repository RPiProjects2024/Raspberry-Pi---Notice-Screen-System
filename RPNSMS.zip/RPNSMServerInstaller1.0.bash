#!/bin/bash
# Raspberry Pi Management System installer.
# Version 1.0 - Created by Nick B, 2022.
# use this after edits to COMPILE Properly: sed -i -e 's/\r$//' RPNSMServerInstaller1.0.bash
# Define Global Variables:

#Clear the screen.
	clear

# Commandline colors:
	RED='\033[1;31m'
	WHITE='\033[1;37m'
	GREEN='\033[1;32m'

# Global Variables:
	VERSION="1.0"  								# Version number. Used in echo strings.
	CMDACTIONS="-y" 							# Default CMD line action for automation.
	NETWORKINTERFACEUPDATED="1" 				# Value is changed to 0 when scripts are correct.
	HOSTUPDATED="1" 							# Value is changed to 0 when scripts are correct.
	MANAGEMENTSYSINPUT="1"						# Value is changed to 0 when scripts are correct.
	CURRENTHOSTNAME="hostname"					# Current host name (Experimental).
	CURRENTIP=$(hostname -I)					# Current IPV4 address before changes are made by the user.
	LXSESSIONDIR="/home/pi/.config/lxsession" 	# Where the LXsession folder must go (used by IF statement).
	VNCSERVICEDIR="/etc/systemd/system/tightvncserver.service" # Where the LXsession folder must go (used by IF statement).
	HOSTSFILE="/etc/hosts"					# Location of the host file. DO NOT CHANGE.
	HOSTNAMEFILE="/etc/hostname"			# Location of the host file. DO NOT CHANGE.
	HOSTFILELINE="raspberrypi"			  	# Default Raspberry Pi name. DO NOT CHANGE.
	NETWORKFILE="/etc/dhcpcd.conf" 			# Location of the network file. DO NOT CHANGE.
	IPV4INPUTCHECK="1"						# Used to ensure the IPV4 field is not left blank.
	DNSINPUTCHECK="1"						# Used to ensure the DNS field is not left blank.
	GATEWAYINPUTCHECK="1"					# Used to ensure the GATEWAY field is not left blank.
	HOSTNAMEINPUTCHECK="1"					# Used to ensure the HOSTNAME field is not left blank.	
	IPV4LINE="0.0.0.1"						# Contains value of IPV4 line in interface file. DO NOT CHANGE.
	DNSLINE="0.0.0.2"						# Contains value of Netmask line in interface file. DO NOT CHANGE.
	GATEWAYLINE="0.0.0.3"					# Contains value of Gateway line in interface file. DO NOT CHANGE.
	
# Begin by updating the Raspberry Pi.
# Check we have an active internet connection.
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Raspberry Pi Notice Screen Management System Installer. Version: $VERSION ${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo "Ensure you have an active internet connection for the installation progress."
	echo "Tasks which will be performed:"
	echo "* Update Raspberry Pi OS to the latest version."
	echo "* Install / update: apache2 & SSHPASS"
	echo "* Install GIT."
	echo "* Copy and configure required start up scripts."
	echo "* Configure IP address and hostname of the Raspberry Pi."
	echo "* Change the password of this Raspberry Pi."
	echo "* Expand the root file system."
	echo -e "${RED}! Run this script as pi with sudo rights.${WHITE}"
	echo "+---------------------------------------------------------------------------+"

# Wait for the user to press ENTER.
	printf "%s " "Press any key to begin."
	read ans
	echo "+---------------------------------------------------------------------------+"


# Check for an internet connection before starting the installer.
	echo "+ Checking for an active internet connection..."
	ping -c12 8.8.8.8 > /dev/null
if [ $? -eq 0 ]; then   
    echo -e "+${GREEN} [OK]${WHITE} Internet connection established!"
	else
# We need a working active connection for the installer to work.
	echo "+---------------------------------------------------------------------------+"
    echo "ERROR! There was a problem during the connection test! (0x00002)"
	echo "Please check your internet connection and confirm this"
	echo "Raspberry Pi is not being blocked by a Firewall."
	echo "+---------------------------------------------------------------------------+"
# List IP addresses
	echo "Current ethernet IP configuration:"
	ifconfig eth0
	exit
fi

# Install Apache.
	echo "+ Installing apache2..."
	sudo apt-get $CMDACTIONS install apache2 > /dev/null
	APACHE2INSTALLRESULT=$?
if [ $APACHE2INSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} apache2 Installed. (Command output: $APACHE2INSTALLRESULT)"
else
	echo -e "!${RED} [FAIL]${WHITE} apache2 failed to install (package may already be installed?) (0x00001)."
fi

# Install GIT
	echo "+ Installing GIT..."
	sudo apt-get $CMDACTIONS install git > /dev/null
	GITINSTALLRESULT=$?
if [ $GITINSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} GIT Installed. (Command output: $APACHE2INSTALLRESULT)"
else
	echo -e "!${RED} [FAIL]${WHITE} GIT failed to install (package may already be installed?) (0x00001)."
fi

# Copy the MSINIT service.
	sudo cp /home/pi/RPNSMS/ASSETS/Services/msinit.service /etc/systemd/system
	MSINITSERVICE=$?

# Set permissions to the MSINIT Service.
	sudo chmod 644 /etc/systemd/system/msinit.service

# Check if the Service file copy was successful.
if [ $MSINITSERVICE -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Management System Initialization Service copied."
else
	echo -e "!${RED} [FAIL]${WHITE} Management System Initialization Service copy failed!"
	echo -e "${RED}!${WHITE} Ensure the user has SUDO rights. (0x00001)"
	exit
fi

# Reload the systemctl daemon.
	sudo systemctl daemon-reload &> /dev/null
	
# Create MSINIT Service to run at start-up.
	sudo systemctl enable msinit.service &> /dev/null
	MSINITENABLE=$?

# Check if the Service file copy was successful.
if [ $MSINITENABLE -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Management System Initialization Service enabled."
else
	echo -e "!${RED} [FAIL]${WHITE} Management System Initialization Service failed to enable!"
	echo -e "${RED}!${WHITE} Ensure the user has SUDO rights. (0x00001)"
	exit
fi

# Set the service file as executable.
	sudo chmod u+x /home/pi/RPNSMS/ASSETS/Services/systemstartup.sh

# Set Pi as the owner of the WWW folder for access.
	sudo chown pi /var/www/html

# Copy sample HTML files to www folder, used by Apache.
	sudo cp -a ASSETS/HTMLExamples /var/www/html
	HTMLSAMPLECOPYRESULT=$?

# Check if the folder copy was successful.
if [ $HTMLSAMPLECOPYRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Sample HTML files copied."
else
	echo -e "!${RED} [FAIL]${WHITE} Sample HTML files failed to copy."
fi

# Install SSHPASS.
	echo "+ Installing SSHPASS..."
	sudo apt-get $CMDACTIONS install sshpass &> /dev/null
# Variable to contain command outcome.
	SSHPASSINSTALLRESULT=$?
if [ $SSHPASSINSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} SSHPASS Installed. (Command output: $SSHPASSINSTALLRESULT)"
else
	echo -e "!${RED} [FAIL]${WHITE} SSHPASS failed to install (package may already be installed?) (0x00001)."
	echo -e "${RED}!${WHITE} Ensure the user has SUDO rights. (0x00001)"
	exit
fi

# After installing all packages, perform one final update check.
	echo "+ Updating Raspberry Pi OS... Do not turn off the system!"
    sudo apt-get $CMDACTIONS update &> /dev/null
	UPDATERESULT=$?
	if [ $UPDATERESULT -eq 0 ]; then
    echo -e "+${GREEN} [OK]${WHITE} Update successful."
else
	echo "+---------------------------------------------------------------------------+"
	echo -e "+${RED} [FAIL] ${WHITE} Update failed! Try again!"
    echo "+---------------------------------------------------------------------------+"
fi

# Now perform the upgrade to Raspberry Pi OS.
	echo "+ Upgrading Raspberry Pi OS... (This may take a while)"
	sudo apt-get upgrade $CMDACTIONS &> /dev/null
# Variable to contain command outcome.
	UPGRADERESULT=$?
	if [ $UPGRADERESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Upgrade successful."
else
    echo "+---------------------------------------------------------------------------+"
    echo -e "+${RED} [FAIL] ${WHITE} Upgrade failed! Try again!"
    echo "+---------------------------------------------------------------------------+"
fi

# NETWORK ADDRESS UPDATE SECTION:

while [ $NETWORKINTERFACEUPDATED -gt 0 ]; do
	printf "\n"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "Network Configuration setup"
	echo -e "${GREEN}Current eth0 IPV4 Address:${WHITE} $CURRENTIP"
	echo -e "This will create a static IPV4 address for eth0 (Ethernet Only)."		
    echo -e "+---------------------------------------------------------------------------+"
	
while [ $IPV4INPUTCHECK -gt 0 ]; do
# Type the IPV4 address.
	printf "\nPlease type an IPV4 address. Use the following format: 0.0.0.0\n"
	read IPV4

if [ -z "$IPV4" ]
then
      echo -e "${RED}[ERROR]${WHITE} The IP Address was left blank!"
else
IPV4INPUTCHECK="0"
fi
done

# Type the IPV4 address again.
	printf "\nPlease type the same IPV4 address again. Use the following format: 0.0.0.0\n"
	read IPV4CHECK

# IF Statement to check if the two fields match.
	if [ $IPV4 == $IPV4CHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} IPV4 matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} IPV4 did not match."
	fi

while [ $DNSINPUTCHECK -gt 0 ]; do
# Type the Netmask.
	printf "\nPlease type the Subnet mask. Use the following format: 0.0.0.0\n"
	read DNS

if [ -z "$DNS" ]
then
      echo -e "${RED}[ERROR]${WHITE} The Subnet mask was left blank!"
else
DNSINPUTCHECK="0"
fi
done

# Type the Netmask again.
	printf "\nPlease type the same Subnet mask again. Use the following format: 0.0.0.0\n"
	read DNSCHECK

# IF Statement to check if the two fields match.
if [ $DNS == $DNSCHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} Subnet mask matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} Subnet mask did not match."
fi

while [ $GATEWAYINPUTCHECK -gt 0 ]; do
# Type the default Gateway.
	printf "\nPlease type the default Gateway. Use the following format: 0.0.0.0\n"
	read GATEWAY

if [ -z "$GATEWAY" ]
then
      echo -e "${RED}[ERROR]${WHITE} The GATEWAY was left blank!"
else
GATEWAYINPUTCHECK="0"
fi
done

# Type the default Gateway again.
	printf "\nPlease type the same default Gateway again. Use the following format: 0.0.0.0\n"
	read GATEWAYCHECK

# IF Statement to check if the two fields match.
if [ $GATEWAY == $GATEWAYCHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} Gateway matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} Gateway did not match."
fi

# Make sure that all 3 fields matched. 
# Then, set NETWORKCOUNT to zero to end while loop.
if [ $NETWORKCOUNT == 3 ]; then
	NETWORKINTERFACEUPDATED="0"

# Apply permissions to network folder. Required to copy the preconfigured file.
#	sudo chmod 777 -R /etc/network/
	sudo chown pi /etc/dhcpcd.conf

#Copy preconfigured interfaces file.
	sudo cp dhcpcd.conf /etc/

# From this section, we now update the IP configuration.
# A full restart is required for the changes to apply.

# Now update the network configuration.
	echo "+ Updating network configuration..."

# IPV4 Address copy operation: 
	sudo sed -i "s/$IPV4LINE/$IPV4/g" "$NETWORKFILE"

# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy IPV4 line."

# Domain Name copy operation.: 
	sudo sed -i "s/$DNSLINE/$DNS/g" "$NETWORKFILE"
# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy Subnet mask line."	

# Netmask Address copy operation.: 
	sudo sed -i "s/$GATEWAYLINE/$GATEWAY/g" "$NETWORKFILE"
# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy Gateway line."

	echo    "+---------------------------------------------------------------------------+"
    echo -e "+${GREEN} [OK]${WHITE} Network interfaces updated."
	echo    "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Updated IPV4 Address: ${WHITE}$IPV4"
	echo -e "${GREEN}Updated Subnet mask: ${WHITE}$DNS"	
	echo -e "${GREEN}Updated Default Gateway: ${WHITE}$GATEWAY"
	echo "When setting up new Notice screens, use the updated IP Address."
	echo -e "${RED}! The changes will be applied after reboot.${WHITE}"
else
	echo -e "!${RED} [FAIL]${WHITE} One or more fields did not match."
# Reset NETWORKCOUNT or it could cause problems.
	NETWORKCOUNT="0"
fi
done

# Define an initial value for the HOSTUPDATED. This will become 0 when the host name
# has been changed correctly. Do not change this value.
while [ $HOSTUPDATED -gt 0 ]; do
# Configure host name
    echo "+---------------------------------------------------------------------------+"
	echo -e "Please type a suitable Hostname for this Raspberry Pi."
	echo -e "Example: NOTICESMS-01. Use ASCII characters only.${WHITE}"
	echo -e "${RED}Note:${WHITE} After the hostname has updated during the setup, It is normal"
	echo -e "to see the following error message: sudo: unable to resolve 'hostname'."
	echo -e "When the installer reboots, this issue should self rectify."	
    echo "+---------------------------------------------------------------------------+"
while [ $HOSTNAMEINPUTCHECK -gt 0 ]; do
	read HOSTNAMEUPDATE

if [ -z "$HOSTNAMEUPDATE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The Hostname was left blank!"
      echo -e "Please type a suitable Hostname for this Raspberry Pi."	  	  
else
HOSTNAMEINPUTCHECK="0"
fi
done

	echo "Typed Hostname: '$HOSTNAMEUPDATE'."
	echo "Please type the hostname once more."
	read HOSTNAMECHECK

# Update the Hostname now. Check that both names match.
	if [ $HOSTNAMEUPDATE == $HOSTNAMECHECK ]; then

# The host name matched, update the host name.
# Update the hostname through raspi-config:
	sudo raspi-config nonint do_hostname $HOSTNAMEUPDATE

# Domain Name copy operation.: 
	sudo sed -i "s/$HOSTFILELINE/$HOSTNAMEUPDATE/g" "$HOSTSFILE"
	sudo sed -i "s/$HOSTFILELINE/$HOSTNAMEUPDATE/g" "$HOSTNAMEFILE"
	
# Change the hostname now to allow tightvnc to configure correctly.
	sudo hostnamectl set-hostname $HOSTNAMEUPDATE

# Restart mDNS daemon service:
	sudo systemctl restart avahi-daemon
	
	
# Output after updating hostname.
    echo "+---------------------------------------------------------------------------+"
    echo -e "+${GREEN} [OK]${WHITE} The Hostname will be updated at the end of the setup."
	echo -e "${GREEN}  Updated hostname: ${WHITE}$HOSTNAMEUPDATE"
	HOSTUPDATED="0"
	else
# The host name did not match. Restart while loop.
	echo -e "!${RED} [FAIL]${WHITE} The host names did not match."
	fi
# Closes the while loop.
done

# Make the user change the password. For security reasons!
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Please update the password to access the Management System.${WHITE}"
	echo -e "${RED}Do NOT use a known default password or the same as the Notice systems!${WHITE}"
	echo "The default password can be found in the setup manual."
	echo "+---------------------------------------------------------------------------+"
# Change password command:
	passwd

	printf "\n"

# Copy the Pi OS Automatic update script...
	sudo cp /home/pi/RPNSMS/AutoUpdate.sh /home/pi
	AUTOUPDSCRIPTCCOPYRESULT=$?

# Check if the script copy was successful.
if [ $AUTOUPDSCRIPTCCOPYRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Automatic Pi OS updater script copied."
else
	echo -e "!${RED} [FAIL]${WHITE} Automatic Pi OS updater script failed to copy!"
	echo -e "${RED}!${WHITE} Ensure the user has SUDO rights. (0x00001)"
	exit
fi

# Display summary of the work done:

# Set Management system scripts as executables.
	echo "+ Setting Management System scripts as executable..."
	sudo chmod u+x /home/pi/RPNSMS/NoticeScreenManagementSystem.bash
	sudo chmod u+x /home/pi/RPNSMS/autoexec.bash
	sudo chmod u+x /home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash
	sudo chmod +x /home/pi/AutoUpdate.sh
	sudo chmod u+x /home/pi/RPNSMS/ASSETS/AdvancedMSOptions.bash

# Setup Automatic update script to run each day. (11:30AM)
    { crontab -l; echo "00 11 * * * /home/pi/AutoUpdate.sh"; } | crontab -
	
# Set folder owners:
	sudo chown -R pi /home/pi/RPNSMS &> /dev/null

# Expand the file system now.
	echo -e "+ ${RED}Expanding the root file system... Do not turn off the system!${WHITE}"
	sudo raspi-config --expand-rootfs > /dev/null
	FSEXPANDTASK=$?

# Check the file system expanded successfully.
if [ $FSEXPANDTASK -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} The file system has expanded."
else
	echo -e "!${RED} [FAIL]${WHITE} The file system failed to expand!"
	echo -e "!${RED} Use the 'sudo raspi-config' interface instead!"
fi

# Update the .bashrc file to automatically load the Management system.
	sudo cp /home/pi/RPNSMS/.bashrc /home/pi
	BASHRCCOPYRESULT=$?

# Check if the folder copy was successful.
if [ $BASHRCCOPYRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} .bashrc file copied."
else
	echo -e "!${RED} [FAIL]${WHITE} .bashrc file failed to copy."
	echo -e "${RED}!${WHITE} Ensure the user has SUDO rights. (0x00001)"
	exit
fi

# Event log entry. This is the first time the eventlog.log file is created:
	echo "$(date "+%D %T")" "$IPV4" ":" "The management system has been deployed." > /home/pi/RPNSMS/eventlog.log

# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log

# From this stage, the Management should be ready to be used as a notice screen.

	printf "\n"

# Display summary of the work done.
	echo "+---------------------------------------------------------------------------+"
	echo "Raspberry Pi Notice Screen Installer. Version: $VERSION."
	echo -e "${GREEN}The initial setup is now complete!${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	printf "\n"
	echo "Task completion status:"
	printf "\n"
	echo "Applications Installed:"

# We will use IF statements to show the EXACT status.
# Applications:

# apache2 install status:
if [ $APACHE2INSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} apache2 Installed."
else
	echo -e "!${RED} [FAIL]${WHITE} apache2 failed to install (package may already be installed?) (0x00001)."
fi

# GIT install status:
if [ $GITINSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} GIT Installed."
else
	echo -e "!${RED} [FAIL]${WHITE} GIT failed to install (package may already be installed?) (0x00001)."
fi

# SSHPASS install status:
if [ $SSHPASSINSTALLRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} SSHPASS Installed."
else
	echo -e "!${RED} [FAIL]${WHITE} SSHPASS failed to install."
fi

# Start up configuration files:
	printf "\n"
	echo "Start up scripts:"

# .bashrc copy status.
if [ $BASHRCCOPYRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} .bashrc file copied."
else
	echo -e "!${RED} [FAIL]${WHITE} .bashrc file failed to copy."
fi

# Check if the MSINIT Service file copy was successful.
if [ $MSINITENABLE -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Management System Initialization Service enabled."
else
	echo -e "!${RED} [FAIL]${WHITE} Management System Initialization Service failed to enable!"
fi

# Check if the script copy was successful.
if [ $AUTOUPDSCRIPTCCOPYRESULT -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Automatic Pi OS updater script copied."
else
	echo -e "!${RED} [FAIL]${WHITE} Automatic Pi OS updater script failed to copy!"
fi

# Network configuration:
	printf "\n"
	echo "Network configuration:"
	echo -e "+ ${GREEN}IPV4 Address: ${WHITE}$IPV4"
	echo -e "+ ${GREEN}Subnet mask: ${WHITE}$DNS"	
	echo -e "+ ${GREEN}Default Gateway: ${WHITE}$GATEWAY"

# Raspberry Pi hostname status:
	printf "\n"
	echo "Raspberry Pi hostname status:"

# Hostname status:
if [ $HOSTNAMEUPDATE == $HOSTNAMECHECK ]; then
    echo -e "+${GREEN} [OK]${WHITE} Hostname updated to $HOSTNAMEUPDATE"
	else
	echo -e "!${RED} [FAIL]${WHITE} Host name update failed."
fi

# Raspberry Pi Updates and upgrades status:
	printf "\n"
	echo "Raspberry Pi update status:"

# Raspberry Pi update status:
	if [ $UPDATERESULT -eq 0 ]; then
    echo -e "+${GREEN} [OK]${WHITE} Raspberry Pi OS update was successful."
else

	echo -e "+${RED} [FAIL] ${WHITE} Raspberry Pi OS update failed!"
fi

# Raspberry Pi upgrade status:
	if [ $UPGRADERESULT -eq 0 ]; then
    echo -e "+${GREEN} [OK]${WHITE} Raspberry Pi OS upgrade was successful."
else
	echo -e "+${RED} [FAIL] ${WHITE} Raspberry Pi OS upgrade failed!"
fi

# Root file system expand command:
	printf "\n"
	echo "Raspberry Pi file system:"
	
if [ $FSEXPANDTASK -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} The file system has been expanded."
else
	echo -e "!${RED} [FAIL]${WHITE} The file system failed to expand!"
	echo -e "!${RED} Use the 'sudo raspi-config' interface instead!"
fi

# Display final instructions to the user:
	echo "+---------------------------------------------------------------------------+"
	echo "You can now begin deploying notice screens, using the provided installer."
	echo "Apache 2 will allow you to host webpages on the management system."
	echo "+---------------------------------------------------------------------------+"

# A restart is required.
	echo -e "${RED}A system restart is now required to apply changes.${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	printf "%s " "Press any key to begin."
	read ans

# Reboot Raspberry Pi system.
	echo "Now restarting the Raspberry Pi system..."
	sudo reboot

# End of application.















	