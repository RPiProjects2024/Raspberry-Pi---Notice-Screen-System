#!/bin/bash
# Raspberry Pi Notice Screen Management System.
# Version 1.0 - Created by Nick B, 2022.
# Use this after edits to COMPILE Properly: sed -i -e 's/\r$//' NoticeScreenManagementSystem.bash

# ------------------------------------------------------------------------------------------------
# This script and its code have been designed to function as part of the notice screen system. 
# Modifying or changing the code and or files stored could cause problems. 
# If you wish to make changes, do so at your own risk.
# If you need to change Management System Parameters, see line 41.
# ------------------------------------------------------------------------------------------------

# Define Global Variables:

# Commandline colors:
	RED='\033[1;31m'
	WHITE='\033[1;37m'
	GREEN='\033[1;32m'

# Global Variables:
	VERSION="1.0"  																	# Version number. Used in echo strings.
	CMDACTIONS="-y" 																# Default CMD line action for automation.
	PICOMMANDDONE="1" 																# Static value is 0. DO NOT CHANGE!
	CURRENTHOSTIP=$(hostname -I)													# Management system IP address. Used for SCP transfers.
	AUTOSTARTTEMPURL="www.google.com"												# The default URL which is updated in the template file.
	AUTOSTARTLOC="/home/pi/RPNSMS/ASSETS/autostart"    								# Where the LXsession folder must go (used by IF statement).
	VIDEOLOC="/home/pi/RPNSMS/ASSETS/Video/display.desktop"  						# Where the AUDIO/VIDEO Function folder must go (used by IF statement).
	SLIDESHOWLOC="/home/pi/RPNSMS/ASSETS/Pictures/autostart"  						# Where the SLIDESHOW Function folder must go (used by IF statement).
	SLIDESHOWDEFAULTTIMER="12"														# The default slideshow timer which is updated in the template file for slideshows.
	AUDIOLOC="/home/pi/RPNSMS/ASSETS/Music/display.desktop" 						# Where the AUDIO Function folder must go (used by IF statement).
	SEDAUTOSTARTLOC="/home/pi/RPNSMS/ASSETS/autostart" 								# Where the LXsession folder must go (used by SED script).	
	PASSWORDCHECKLOOP="1" 															# Ensures the passwords for accessing Pi devices match.
	SLIDESHOWTIMERSET="1"															# Loop until the IF statement is correctly matched.
	SLIDESHOWMUSIC="1"																# Loop until the IF statement is correctly matched.
	MESSAGETIMERSET="1"																# Loop until the IF statement is correctly matched.
	MESSAGESTRINGTYPED="1"															# Loop until the IF statement is correctly matched.
	URLSTRINGTYPED="1"																# Loop until the IF statement is correctly matched.
	URLUPDATETASK="0" 																# Handles if URL copy/update jobs have completed correctly.
	RPNSMSSCRIPT="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash"				# Location of this script on the Management System.
	RPNMASSSCRIPT="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash"	# Location of the MASS script on the Management System.
	RPNAUTOEXECSCRIPT="/home/pi/RPNSMS/autoexec.bash"								# Location of the autoexec script on the Management System. 
	CURRENTTIME=$(date "+%D %T")													# The current date and time for logging purposes.
    YNOPTION="0" 																	# Used to determine yes or no selections.
	DISKCHOICESELECTION="1"															# Used to close disk selection loop.

# Management System Parameters:
	PIUSER="pi" # Username for accessing Raspberry Pi devices. Default is pi.

# Delete the setup script to prevent accidental changes to the configuration.
	sudo rm -r /home/pi/RPNSMS/RPNSMServerInstaller1.0.bash &> /dev/null

while [ $PICOMMANDDONE -gt 0 ]; do

	clear
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager. ${GREEN}Version: $VERSION ${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Please type the IP Address of the Raspberry Pi you wish to configure:${WHITE}"
	echo -e "${GREEN}Type EXIT to return to the main menu.${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	read IPADDRESS

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $IPADDRESS == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $IPADDRESS == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

# Check the IP is alive.
	echo -e "+ Checking connection..."
	ping -c2 $IPADDRESS &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

while [ $PASSWORDCHECKLOOP -gt 0 ]; do		
# Ask for the password to use.
	echo "+---------------------------------------------------------------------------+"
	echo -e "Username being used: ${GREEN}$PIUSER ${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo "Type the password for accessing the pi"
	read -s PIPASSWORD
	echo -e "+ Logging in..."

# Simple way to check the password/IP address are actually correct.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS echo "Connection successful." &> /dev/null
	AUTHCHECK=$?
	
if [ $AUTHCHECK == 0 ]; then	
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
	PASSWORDCHECKLOOP="0"

else
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP or password!"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(LOGIN):" "The management system was unable to connect. Incorrect IP or password!" >> /home/pi/RPNSMS/eventlog.log
	sleep 4s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNSMSSCRIPT"
fi	
done	

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log

# Collect data from the Notice screen.
	echo -e "+ Please wait, checking status..."

# Raspberry Information Variables:

# GPU/CPU Temperature - Get the CPU Temperature after login:
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to obtain Pi temperature." >> /home/pi/RPNSMS/eventlog.log
	PITEMP=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo vcgencmd measure_temp) &> /dev/null

# Obtain the Hostname:
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to obtain Pi hostname." >> /home/pi/RPNSMS/eventlog.log
	PIHOSTNAME=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo hostname) &> /dev/null 

# URL mode? (firefox-ESR)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'URL' (1-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSURL=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo pgrep -x "firefox-esr") &> /dev/null
	PISTATUSURLOUTPUT=$?

# Slideshow mode? (feh)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'SLIDESHOW' (2-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSSLIDESHOW=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo pgrep -x "feh") &> /dev/null
	PISTATUSSLIDESHOWOUTPUT=$?

# Video or Audio Mode? (vlc)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'VIDEO/AUDIO' (3-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSVLC=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo pgrep -x "vlc") &> /dev/null
	PISTATUSVLCOUTPUT=$?

# VNC agent running? (vncagent)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-INFO):" "Attempting to check if the 'VNC Agent' is running." >> /home/pi/RPNSMS/eventlog.log
	PISTATUSVNC=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo pgrep -x "vncagent") &> /dev/null
	PISTATUSVNCOUTPUT=$?

# After attempting to collect information variables, create log entry that the system is ready for changes to be made:
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(Management-System):" "Ready for changes to be made to the target Pi." >> /home/pi/RPNSMS/eventlog.log

# Ask the user to choose an option.
	clear
	echo "+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager. ${GREEN}Version: $VERSION ${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}IP Address:${WHITE} $IPADDRESS ${GREEN}Username:${WHITE} $PIUSER                       [CPU $PITEMP]" # <Padding to make this appear on the right side of the screen.
	echo -e "${GREEN}Hostname:${WHITE} $PIHOSTNAME"

# Is the notice screen running in URL mode?
if [ $PISTATUSURLOUTPUT == 0 ]; then
	echo -e "URL Mode: ${GREEN}SET ${WHITE}"
	else
	echo -e "URL Mode: ${RED}OFF ${WHITE}"
fi

# Is the notice screen running in Video/Audio mode?
if [ $PISTATUSVLCOUTPUT == 0 ]; then
	echo -e "Video/Audio Mode: ${GREEN}SET ${WHITE}"
	else
	echo -e "Video/Audio Mode: ${RED}OFF ${WHITE}"
fi

# Is the notice screen running in Slideshow mode?
if [ $PISTATUSSLIDESHOWOUTPUT == 0 ]; then
	echo -e "Slideshow Mode: ${GREEN}SET ${WHITE}"
	else
	echo -e "Slideshow Mode: ${RED}OFF ${WHITE}"
fi

# Is the VNC Service running?
if [ $PISTATUSVNCOUTPUT == 0 ]; then
	echo -e "VNC Access: ${GREEN}RUNNING ${WHITE}"
	else
	echo -e "VNC Access: ${RED}OFF ${WHITE}"
fi
	echo -e "Please choose one of the following options:"
	echo -e "+---------------------------------------------------------------------------+${WHITE}"

# List values:	
	options=("Update notice screen URL" "Play Video" "Play Slideshow" "Play Audio" "Copy USB upload" "Update and upgrade Pi" "Restart Pi" "Shutdown Pi" "Delete Content" "Repair Pi" "Display Message" "Exit")
select opt in "${options[@]}"
do
    case $opt in
        "Update notice screen URL")
	echo "+---------------------------------------------------------------------------+"
	echo "Update notice screen URL:"
	echo "+---------------------------------------------------------------------------+"

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
	echo "+ Inspecting Pi..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the notice screen running in URL mode?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(URL):" "Unable to change to URL mode. The target Pi appears to be a management system! (0x00007)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system! (0x00007)"
	echo -e "The specified command will not work."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
else
	echo -e "+${GREEN} [OK]${WHITE} Target Pi is a notice screen."
	printf "\n"
fi

while [ $URLSTRINGTYPED -gt 0 ]; do
	echo "Type the URL you wish update on the PI."
	echo -e "Example: ${GREEN}SERVER-NAME/index.html${WHITE}"
	read URLUPDATE

if [ -z "$URLUPDATE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The URL was left blank!"
else

# When a URL is typed, end the loop to check for a value.
	  URLSTRINGTYPED="1"


# Ask if the user would like to also enable Audio playback:


# Option to enable AUDIO for specific modes where Audio can be used together.
# SINGLE MODE Script:

	printf "\n"
	echo -e "+ Would you also like to enable audio playback with this mode?"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] Audio will be enabled..."
	ENABLEAUDIO="1"

else

	echo -e "+ [OK] Audio will not be enabled..."
	ENABLEAUDIO="0"
fi


# Remove audio/video playback (used to restore just notice screen functionality).
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback."	
	
# Remove existing URL Script.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null

# Set Pi as the owner of the URL script path.	
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo chown pi /home/pi/.config/lxsession/LXDE-pi	
	
# Restore URL script file to the Pi (Enabling video playback deletes it).
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADDRESS:/home/pi/.config/lxsession/LXDE-pi
	echo "+ Replaced URL Script template file..."	

# Modify the autostart template file on the Management system.
	echo "+ Please wait..."
	sudo sed -i -- 's#'"$AUTOSTARTTEMPURL"'#'"$URLUPDATE"'#g' "$SEDAUTOSTARTLOC"
	SEDCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SEDCOPYOUTPUT == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
else
	URLUPDATETASK="0"
fi

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADDRESS:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
	else
	URLUPDATETASK="0"
fi		

# Now replace the ORIGINAL autostart template on the Management system.
	sudo cp -r /home/pi/RPNSMS/ASSETS/autostartbak/autostart /home/pi/RPNSMS/ASSETS
	AUTOSTARTTEMPTASK=$?

# Check the template autostart file has copied back to the Management system.
if [ -f "$AUTOSTARTLOC" ]; then
	echo -e "+${GREEN} [OK]${WHITE} Management system autostart file reset."
	((URLUPDATETASK=URLUPDATETASK+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(URL):" "The autostart script failed to copy from the management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Management system autostart file failed to copy or does not exist!"
	URLUPDATETASK="0"
exit
fi

# Check all above scripts completed.
if [ $URLUPDATETASK == 3 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully updated on $IPADDRESS"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."

# Check if the user wanted to enable Audio playback:
if [ $ENABLEAUDIO == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Enabling Audio..."

# Adding the Audio mode (Must be placed after the selected mode has been applied:

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo chmod 777 /etc/xdg/autostart
	echo "+ Set permissions to copy the required file."

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADDRESS:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADDRESS"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"
	echo "Are you running this application as pi with sudo rights?"
	echo "Has the device been configured with the Notice Screen setup?"

fi

else

	echo -e "+ ${GREEN}[OK]${WHITE} Audio was not selected to be enabled at this time."

fi


	echo "+ Restarting Pi..."
# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	sleep 5s 
	echo "+ Reset command was sent."

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(URL):" "+-----------------URL update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"	
# End of section.
	break
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(URL):" "Failed to apply the URL:" "$URLUPDATE" "(0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} The URL update failed! (0x00004)"
	echo "Are you running this application as pi with sudo rights?"
	echo "Has the device been configured with the Notice Screen setup?"
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"

fi
fi		
done			
break
 
           ;;
			
# Play Video or Audio

        "Play Video")
	echo "+---------------------------------------------------------------------------+"
	echo "Play Video:"
	echo "+---------------------------------------------------------------------------+"
	echo "This will enable video output on the target Raspberry Pi."
	echo -e "${GREEN}Supported audio & video files: .mp4 .avi"
	echo "Use the following name formats for an order: 1.Video.mp4 2.Video.mp4 etc..."
	echo -e "${RED}Place files in the following location on this Pi: /home/pi/Videos"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable audio/video playback, please choose 'Update notice screen URL'${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
	echo "+ Inspecting Pi..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the notice screen actually a Management system?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(VIDEO):" "Unable to change to VIDEO mode. The target Pi appears to be a management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system!"
	echo -e "The specified command will not work."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
else
	echo -e "+${GREEN} [OK]${WHITE} Target Pi is a notice screen."
	printf "\n"
fi

# Remove audio/video playback.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback."	

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Video/display.desktop
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo chmod 777 /etc/xdg/autostart
	echo "+ Set permissions to copy the required file."

# Delete the Notice Screen start up file.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script..."

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADDRESS:/etc/xdg/autostart
	SSHAUDIOVIDEOCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADDRESS"
	echo "+ Restarting Pi..."

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	sleep 5s 
	echo "+ Reset command was sent."

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(VIDEO):" "+-----------------VIDEO update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log	

# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"	
# End of section.
	break
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(VIDEO):" "The management system failed to enable video playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004)"
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break

fi

else
	exec "$RPNAUTOEXECSCRIPT"
fi

			
            ;;
			
# Play SlideShow

        "Play Slideshow")
	echo "+---------------------------------------------------------------------------+"
	echo "Play SlideShow:"
	echo "+---------------------------------------------------------------------------+"
	echo "This will enable a picture slideshow on the target Raspberry Pi."
	echo -e "${GREEN}Supported image files: .jpg .png .bmp .gif .tiff and many more."
	echo -e "${RED}Place Pictures in the following location on this Pi: /home/pi/Pictures"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable the Slideshow, please choose 'Update notice screen URL'${WHITE}"
	echo -e "${RED}or 'Play Video' from the management system.${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
	echo "+ Inspecting Pi..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the notice screen running in URL mode?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "Unable to change to SLIDESHOW mode. The target Pi appears to be a management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system!"
	echo -e "The specified command will not work."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
else
	echo -e "+${GREEN} [OK]${WHITE} Target Pi is a notice screen."
	printf "\n"
fi

# Specify the slideshow time:
while [ $SLIDESHOWTIMERSET -gt 0 ]; do	
	printf "\n"
	echo -e "Type a number between: ${GREEN}5-3600 seconds${WHITE} to specify when"
	echo -e "the next picture should show on the screen:"
	read SLIDESHOWTIMERENTRY
	printf "\n"

if [[ "$SLIDESHOWTIMERENTRY" -ge 5 && "$SLIDESHOWTIMERENTRY" -lt 3601 ]]; then

	echo -e "${GREEN}[OK]${WHITE} $SLIDESHOWTIMERENTRY seconds will be applied to the Slideshow."
	SLIDESHOWTIMERSET="0"
	else
	echo -e "${RED}[ERROR]${WHITE} Please type a number between 5-3600 seconds."
fi

done

# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(SLIDESHOW):" "The management system applied $SLIDESHOWTIMERENTRY seconds to the Slideshow template." >> /home/pi/RPNSMS/eventlog.log


# Option to enable AUDIO for specific modes where Audio can be used together.
# SINGLE MODE Script:

	printf "\n"
	echo -e "+ Would you also like to enable audio playback with this mode?"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] Audio will be enabled..."
	ENABLEAUDIO="1"

else

	echo -e "+ [OK] Audio will not be enabled..."
	ENABLEAUDIO="0"
fi

# Modify the autostart template file on the Management system.
	echo "+ Please wait..."
	sudo sed -i -- 's#'"$SLIDESHOWDEFAULTTIMER"'#'"$SLIDESHOWTIMERENTRY"'#g' "$SLIDESHOWLOC"
	SEDCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SEDCOPYOUTPUT == 0 ]; then
# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(SLIDESHOW):" "The management system modified the Slideshow template." >> /home/pi/RPNSMS/eventlog.log
	((SLIDESHOWTIMERUPDATECMD=SLIDESHOWTIMERUPDATECMD+1))
	echo -e "${GREEN}[OK]${WHITE} The Slideshow template has been modified."
else
	URLUPDATETASK="0"
# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(SLIDESHOW):" "The management system failed modify the Slideshow template!" >> /home/pi/RPNSMS/eventlog.log
		echo -e "${RED}[ERROR]${WHITE} Unable to modify the Slideshow template. FATAL ERROR!"
		sleep 4s
		exec "$RPNAUTOEXECSCRIPT"
fi
	
# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Pictures/autostart
	printf "\n"

# Set Pi as the owner of the URL script path.	
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo chown pi /home/pi/.config/lxsession/LXDE-pi
	echo "+ Set permissions to copy the required file."

# Delete the Notice Screen start up file.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script..."

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADDRESS:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT=$?

# Now replace the ORIGINAL autostart template on the Management system.
	sudo cp -r /home/pi/RPNSMS/ASSETS/Pictures/bak/autostart /home/pi/RPNSMS/ASSETS/Pictures
	AUTOSTARTTEMPTASKSLIDESHOW=$?

# Check the template autostart file has copied back to the Management system.
if [ $AUTOSTARTTEMPTASKSLIDESHOW == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "The management system slideshow template file has been reset." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Management system slideshow autostart file reset."
	((URLUPDATETASK=URLUPDATETASK+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "The slideshow autostart template failed to reset!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Management system autostart file failed to copy or does not exist!"
	URLUPDATETASK="0"
exit
fi

# To ensure the Slideshow script completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADDRESS"


# Check if the user wanted to enable Audio playback:
if [ $ENABLEAUDIO == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Enabling Audio..."

# Adding the Audio mode (Must be placed after the selected mode has been applied:

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo chmod 777 /etc/xdg/autostart
	echo "+ Set permissions to copy the required file."

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADDRESS:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADDRESS"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"
	echo "Are you running this application as pi with sudo rights?"
	echo "Has the device been configured with the Notice Screen setup?"

fi

else

	echo -e "+ ${GREEN}[OK]${WHITE} Audio was not selected to be enabled at this time."

fi

	echo "+ Restarting Pi..."

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	sleep 5s 
	echo "+ Reset command was sent."
	
# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "+-----------------SLIDESHOW update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log
	
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"	
# End of section.

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SLIDESHOW):" "The management system failed to enable slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004)"
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break
fi

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
            ;;			

# Play Audio

        "Play Audio")
	echo "+---------------------------------------------------------------------------+"
	echo "Play Audio:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}(If the Pi is set to play Videos, update the URL first, before adding audio!)${WHITE}"
	echo "This will enable audio output in the background on the target Raspberry Pi"
	echo "and play while the Notice screen is running, or from a Slideshow."
	echo -e "${GREEN}Supported audio: .wav .mp3 .ogg"
	echo "Use the following name formats for an order: 1.Song1.mp3 2.Song2.mp3 etc..."
	echo -e "${RED}Place files in the following location on this Pi: /home/pi/Music"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable audio playback, please choose 'Update notice screen URL'${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
	echo "+ Inspecting Pi..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the notice screen running in URL mode?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "Unable to change to AUDIO mode. The target Pi appears to be a management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system!"
	echo -e "The specified command will not work."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
else
	echo -e "+${GREEN} [OK]${WHITE} Target Pi is a notice screen."
	printf "\n"
fi

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS sudo chmod 777 /etc/xdg/autostart
	echo "+ Set permissions to copy the required file."

# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADDRESS:/etc/xdg/autostart
	SSHAUDIOVIDEOCOPYOUTPUT=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADDRESS"
	echo "+ Restarting Pi..."

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	sleep 5s 
	echo "+ Reset command was sent."

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "+-----------------AUDIO update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log
	
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"	
# End of section.
	break
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"
	echo "Are you running this application as pi with sudo rights?"
	echo "Has the device been configured with the Notice Screen setup?"
	sleep 5s

# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break

fi	

else
	exec "$RPNAUTOEXECSCRIPT"
fi
		
            ;;			
	
       "Update and upgrade Pi")
	printf "\n"
	echo "+---------------------------------------------------------------------------+"
    echo "Update and upgrade Raspberry Pi:"
	echo "+---------------------------------------------------------------------------+"

# Update the Raspberry Pi.
	echo "+ Updating Raspberry Pi OS @ $IPADDRESS..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS update &> /dev/null
	PIUPDATETASK=$?
 
# Check the output of the update command.
if [ $PIUPDATETASK -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi update was successful."
	sleep 5s
			#break
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE} The Update failed! Restart the Pi and try again."
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break
fi

# Now upgrade the Raspberry Pi.
	echo "+ Upgrading Raspberry Pi OS @ $IPADDRESS..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS upgrade &> /dev/null
	PIUPGRADETASK=$?

# Check the output of the upgrade command.			
if [ $PIUPGRADETASK -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi upgrade was successful."
	echo -e "+${GREEN} [WARN]${WHITE} A reboot is advised."
	sleep 5s

# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"

			break
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE} The Update failed! Restart the Pi and try again."
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break
fi
            ;;
        "Restart Pi")
	echo "+---------------------------------------------------------------------------+"
	echo "Restart Pi:"
	echo "+---------------------------------------------------------------------------+"

# Restart the Raspberry Pi.

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Restarting Pi @ $IPADDRESS..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	echo "+ Restart command was sent."
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break
            ;;
        "Shutdown Pi") 
	echo "+---------------------------------------------------------------------------+"
	echo "Shutdown Pi:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "+${RED} Are you sure you want to shutdown this Notice screen?${WHITE}"
											  										  
# Prompt for the user to confirm the shutdown command:
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then


# Shutdown the Raspberry Pi.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Shutting down Pi @ $IPADDRESS..."

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to shutdown."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a shutdown notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -h now
	echo "+ Shutdown command was sent."
	sleep 2s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
	break

else
	exec "$RPNAUTOEXECSCRIPT"
fi


			;;
        "Perform mass change")
          	exec "$RPNMASSSCRIPT"
			
			;;
        "Repair Pi")
#This will reinstall all required applications, used for the Notice system.
	echo "+---------------------------------------------------------------------------+"
	echo "Repair Pi:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}If there are problems with certain applications launching, you can${WHITE}"
	echo -e "${GREEN}use this to reinstall all software used by the Notice system.${WHITE}"
	echo -e "${GREEN}The Raspberry Pi will also perform an update and upgrade.${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then
	printf "\n"
	echo "+ Please wait..."

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the Pi running Apache?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "Unable to perform REPAIR mode. The target Pi appears to be a management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system!"
	echo -e "Please use the 'Repair Management Pi' from the Notice Screen Manager."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
	else

# Repair SSHPASS.
	echo "+ Reinstalling SSHPASS..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS install --reinstall sshpass &> /dev/null
# Variable to contain command outcome.
	SSHPASSINSTALLRESULT=$?
if [ $SSHPASSINSTALLRESULT -eq 0 ]; then
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system reinstalled SSHPASS." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} SSHPASS reinstalled..."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system failed to reinstall SSHPASS! (0x00001)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} SSHPASS failed to install/uninstall. (0x00001)"
fi
	printf "\n"

# Repair Firefox-ESR.
	echo "+ Reinstalling Firefox-ESR browser..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS install --reinstall firefox-esr &> /dev/null
# Variable to contain command outcome.
	FIREFOXINSTALLRESULT=$?
if [ $FIREFOXINSTALLRESULT -eq 0 ]; then
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system reinstalled Firefox-ESR." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Firefox-ESR browser reinstalled..."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system failed to reinstall Firefox-ESR! (0x00001)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Firefox-ESR browser failed to install/uninstall. (0x00001)"
fi
	printf "\n"

# Repair VLC Player.
	echo "+ Reinstalling VLC Player..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS install --reinstall vlc &> /dev/null
# Variable to contain command outcome.
	VLCINSTALLRESULT=$?
if [ $VLCINSTALLRESULT -eq 0 ]; then
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system reinstalled VLC Player." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VLC reinstalled..."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system failed to reinstall VLC Player! (0x00001)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} VLC failed to install/uninstall. (0x00001)"
fi
	printf "\n"

# Repair feh.
	echo "+ Reinstalling feh..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS install --reinstall feh &> /dev/null
# Variable to contain command outcome.
	FEHINSTALLRESULT=$?
if [ $FEHINSTALLRESULT -eq 0 ]; then
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system reinstalled feh." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} feh Installed. (Command output: $FEHINSTALLRESULT)"
else
	echo -e "!${RED} [FAIL]${WHITE} feh failed to install/uninstall. (0x00001)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system failed to reinstall feh! (0x00001)" >> /home/pi/RPNSMS/eventlog.log
fi
	printf "\n"

# Install unclutter.
	echo "+ Reinstalling unclutter..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo apt-get $CMDACTIONS install --reinstall unclutter &> /dev/null
# Variable to contain command outcome.
	CLUTTERINSTALLRESULT=$?
if [ $CLUTTERINSTALLRESULT -eq 0 ]; then
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system reinstalled unclutter." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} unclutter reinstalled..."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(REPAIR):" "The management system failed to reinstall unclutter! (0x00001)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} unclutter failed to install/uninstall. (0x00001)"
fi
	printf "\n"

# Perform Raspberry Pi OS update. 
	echo "+ Updating Raspberry Pi OS... Do not turn off the system!"
    sudo apt-get $CMDACTIONS update &> /dev/null
	UPDATERESULT=$?
	if [ $UPDATERESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} Update successful."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE} Update failed!"
fi
	printf "\n"

# Perform Raspberry Pi OS upgrade. 
	sudo echo "+ Upgrading Raspberry Pi OS... Do not turn off the system! (This may take a while)"
	sudo apt-get -y upgrade &> /dev/null
# Variable to contain command outcome.
	UPGRADERESULT=$?
	if [ $UPDATERESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Upgrade successful."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL] ${WHITE} Upgrade failed!"
fi
	printf "\n"
	echo -e "+ [OK] The repair has been completed. The Raspberry Pi will now reboot."
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM):" "The management system sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Restarting Pi @ $IPADDRESS..."

# Display notification on Notice screen:
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --notification --text '"This Notice screen is about to reboot."' &> /dev/null
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(SYSTEM-NOTIFICATION):" "The management sent a reboot notification to the Notice screen." >> /home/pi/RPNSMS/eventlog.log

	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo shutdown -r now
	sleep 5s

# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"
fi

else
	exec "$RPNAUTOEXECSCRIPT"
fi

			;;
        "Exit")
            exec "$RPNAUTOEXECSCRIPT"
            ;;
        "Delete Content")
	echo "+---------------------------------------------------------------------------+"
	echo "Delete Content:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "This will ${RED}delete${WHITE} the contents of the ${RED}Music${WHITE}, ${RED}Video ${WHITE}and ${RED}Music ${WHITE}folder"
	echo -e "from the following Raspberry Pi device:"
	echo -e "${RED}-+ $IPADDRESS"	
	echo -e "${RED}This process is irreversible!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Begin the process:
	echo -e "+ Starting deletion process..."
  
	echo "+ Starting deletion process... $IPADDRESS [1-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the Music folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Music and Video folder." >> /home/pi/RPNSMS/eventlog.log


# Event log entry:
	sudo echo "$(date "+%D %T")" "(DELETE CONTENT):" "+-----------------DELETE CONTENT task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log
	
# Deletion job has completed:
echo -e "+ ${GREEN}[OK]${WHITE} The content deletion command has completed successfully."

sleep 3

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"


else

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
	
fi

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"

			break
            ;;
			
        "Display Message") 
	echo -e "+---------------------------------------------------------------------------+"
	echo -e  "${GREEN}Display Message${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "Use this to display a timed message on the Raspberry Pi screen."
	echo -e "The message will display over any open Windows."
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

# Check if the Raspberry Pi is a management system. This is done by checking for Apache.
	echo "+ Inspecting Pi..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADDRESS sudo pgrep -x "apache2" &> /dev/null	
	CHECKPIBUILD=$?

# Is the notice screen running in URL mode?
if [ $CHECKPIBUILD == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-MESSAGE):" "Unable to apply the message feature. The target Pi appears to be a management system!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} This Raspberry Pi appears to be a Management system!"
	echo -e "The specified command will not work."
	sleep 4s
# Restart the Management System.
	exec "$RPNAUTOEXECSCRIPT"	
else
	echo -e "+${GREEN} [OK]${WHITE} Target Pi is a notice screen."
	printf "\n"
fi

# Specify the message time:
while [ $MESSAGETIMERSET -gt 0 ]; do	
	echo -e "Type a number between: ${GREEN}5-300 seconds${WHITE} to specify"
	echo -e "how long the message will show on screen:"
	read MESSAGETIMEENTRY
	printf "\n"

if [[ "$MESSAGETIMEENTRY" -ge 5 && "$MESSAGETIMEENTRY" -lt 301 ]]; then

	echo -e "${GREEN}[OK]${WHITE} $MESSAGETIMEENTRY seconds will be applied to the message."
	MESSAGETIMERSET="0"
	else
	echo -e "${RED}[ERROR]${WHITE} Please type a number between 5-300 seconds."
fi

done


while [ $MESSAGESTRINGTYPED -gt 0 ]; do
	echo "Type the message you want to display:"
	read PIMESSAGE

if [ -z "$PIMESSAGE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The message was left blank!"
else

# When a message is typed, end the loop to check for a value.
	MESSAGESTRINGTYPED="0"
	printf "\n"
fi
done


# Display Message on DISPLAY 0: on target Raspberry Pi:
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer..."	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADDRESS DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &
	PIMESSAGEOUTPUT=$?
	
if [ $PIMESSAGEOUTPUT == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-MESSAGE):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	sleep 5s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"

else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen!"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PI-MESSAGE):" "Failed to display the requested message to the target notice screen!" >> /home/pi/RPNSMS/eventlog.log
	sleep 4s
# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
fi	
else
	exec "$RPNAUTOEXECSCRIPT"
fi

			;;
        "Perform mass change")
          	exec "$RPNMASSSCRIPT"
			
			;;
		"Copy USB upload")

	echo "+---------------------------------------------------------------------------+"
	echo "Upload content from USB:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${WHITE}Use this to upload media from a designated USB Storage device directly"
	echo -e "${WHITE}To a Notice screen. You must use the advanced options menu and "
	echo -e "${WHITE}select 'Setup USB Media Uploader' to configure a USB storage ${WHITE}"
	echo -e "device for compatibility before proceeding."
	echo "+---------------------------------------------------------------------------+"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ ${GREEN}Please connect a USB storage device to the Management System...${WHITE}"
	read -p "! Press any key when ready..."

	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s


while [ $DISKCHOICESELECTION -gt 0 ]; do
# Show connected devices:
	echo "+---------------------------------------------------------------------------+"
	lsblk	
	echo "+---------------------------------------------------------------------------+"
	echo -e "Type the NAME of the device you wish to use as a USB Media device."
	echo -e "${GREEN}To refresh, leave blank and press ENTER.${WHITE}"
	echo -e "${GREEN}NAME Example: ${WHITE}sda1${WHITE}"
	echo -e "Type EXIT to return to the main menu."
	read USBCLONESELECTION

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $USBCLONESELECTION == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $USBCLONESELECTION == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

if [ -z "$USBCLONESELECTION" ]
then
# Clear the screen to avoid confusion with the previous lsblk command.
	clear
	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s
else
	DISKCHOICESELECTION="0"
fi
done

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Confirm USB Media Storage device parameters!${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Please confirm the following details:${WHITE}"
	echo -e "+ Device NAME to use as Media upload device: $USBCLONESELECTION"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	sudo mount /dev/$USBCLONESELECTION /media &> /dev/null
	USBMOUNTOP=$?

if [ $USBMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Mounted: $USBCLONESELECTION successfully."


	# Define folder locations (event logging):
	USBHTMLLOC="/var/www/html"
	USBVIDEOSLOC="/media/Videos"
	USBPICTURESLOC="/media/Pictures"
	USBMUSICLOC="/media/Music"
	USBFOLDERMISSING="0" # An initial value is given to prevent an empty var, should folders already exists on the USB device.

# Option to enable HTML upload with USB:
# SINGLE MODE Script:

	printf "\n"
	echo -e "+ Would you also just like to upload HTML files?"
	echo -e "Note:${GREEN} HTML files will be uploaded to the Management System for use with Apache"
	echo -e "to the following location: '/var/www/html'.${WHITE}"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] HTML will be uploaded to the Management system..."
	UPLOADHTMLONLY="1"

else

	echo -e "+ [OK] HTML will be not be uploaded to the Management system..."
	UPLOADHTMLONLY="0"
fi

# Confirm the directories were created successfully:	
# Check if the HTML folder exists on the USB Storage device.	

	echo -e "+ Inspecting USB storage device...${WHITE}"

	printf "\n"

	echo -e "+ Checking the folders now exist:"

if [ -d /media/html ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBHTMLLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))

else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBHTMLLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBHTMLLOC does not exist on USB storage device!"

fi	

if [ -d /media/Videos ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBVIDEOSLOC exists."
# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
			
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBVIDEOSLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBVIDEOSLOC does not exist on USB storage device!"

fi

# Check if the Pictures folder exists on the USB Storage device.	
if [ -d /media/Pictures ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBPICTURESLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBPICTURESLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBPICTURESLOC does not exist on USB storage device!"
	
fi

# Check if the Music folder exists on the USB Storage device.	
if [ -d /media/Music ];
then

    echo -e "+${GREEN} [OK]${WHITE} $USBMUSICLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBMUSICLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBMUSICLOC does not exist on USB storage device!"
	
fi


if [ $USBFOLDERMISSING -eq 4 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The required folders exist for the specified USB storage device." >> /home/pi/RPNSMS/eventlog.log

	printf "\n"
	echo -e "+${GREEN} [OK]${WHITE} The USB Storage device contains the required folders."
	
# Start the copy procedure to the Management System:
# Start copying the folder contents to the Management system:

	echo -e "+ Folder transfer status:"
	printf "\n"


# Video files:

	echo -e "+ Copying the Videos folder and its contents..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADDRESS:/home/pi
	VIDEOCOPYSTAT=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system copied the Videos folder from $USBCLONESELECTION." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder from $USBCLONESELECTION."
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system failed to copy the Videos folder from $USBCLONESELECTION! (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder from $USBCLONESELECTION! FATAL ERROR! (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADDRESS:/home/pi/
	PICTURECOPYSTAT=$?

# Confirm the Pictures folder copied:
if [ $PICTURECOPYSTAT -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system copied the Picture folder from $USBCLONESELECTION." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Picture folder from $USBCLONESELECTION."
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system failed to copy the Pictures folder from $USBCLONESELECTION! (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Picture folder from $USBCLONESELECTION! FATAL ERROR! (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADDRESS:/home/pi/
	MUSICCOPYSTAT=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system copied the Music folder from $USBCLONESELECTION." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder from $USBCLONESELECTION."
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system failed to copy the Music folder from $USBCLONESELECTION! (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder from $USBCLONESELECTION! FATAL ERROR! (0x00010)"
fi

	printf "\n"

# Check if the user wanted to upload HTML:
# Should the user say yes:
if [ $UPLOADHTMLONLY == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Uploading HTML at this time..."

# Copy the HTML files to the apache folder on the Management System:

	echo -e "+ Copying the html folder and its contents..."
	sudo cp -r /media/html/ /var/www/ &> /dev/null
	HTMLCOPYSTAT=$?

# Confirm the HTML folder copied:
if [ $HTMLCOPYSTAT -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system copied the html folder from $USBCLONESELECTION." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the html folder from $USBCLONESELECTION."
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system failed to copy the html folder from $USBCLONESELECTION! (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the html folder from $USBCLONESELECTION! FATAL ERROR! (0x00010)"
fi

	printf "\n"

# Should the user say no:
else

	echo -e "+ ${GREEN}[OK]${WHITE} HTML was not uploaded at this time."

fi


# The file transfer scripted has completed from this stage:

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "+${GREEN} [DONE]${WHITE} The USB Storage Media has transferred to the Management system."
	echo -e "+${WHITE} Confirm the 'folder transfer status' passed with ${GREEN}[OK]${WHITE}. Deploy the Media"
	echo -e "+${WHITE} files through the Management system, using either: 'Single Change mode'"
	echo -e "+${WHITE} or 'Perform Mass change' and selecting: 'Copy USB upload'."
	echo -e "+---------------------------------------------------------------------------+"

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $USBCLONESELECTION..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

	read -p "! Press any key to return to the main menu..."
	exec "$RPNAUTOEXECSCRIPT"
	
fi


# If there's a problem with mounting the USB:
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOADER):" "There was a problem creating the folders on the USB Storage device! (0x00010)" >> /home/pi/RPNSMS/eventlog.log


fi
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to Mount: $USBCLONESELECTION! (0x00008)"

# Unmount the disk to prevent issues:	
	echo -e "+ Attempting to eject $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi
fi

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Attempting to eject $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

	printf "\n"

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOADER):" "There was a problem creating the folders on the USB Storage device! (0x00010)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "!${RED}[FAIL]${WHITE} There was a problem copying media files from the USB Storage device!"
	echo -e "! Ensure files were copied to the USB Storage device.(0x00010)"
	echo -e "!${WHITE} Use the advanced options menu and select 'Setup USB Media Uploader'"
	echo -e "! to reconfigure the USB Storage device and try again."
	echo -e "+---------------------------------------------------------------------------+"
	read -p "! Press any key to return to the main menu..."
	clear
	exec "$RPNAUTOEXECSCRIPT"
			;;
			
        *) echo "invalid option $REPLY";;
    esac
done


# If the IP Address does not reply, end the whole loop.
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADDRESS" "(PING):" "The management system failed to PING the target Pi! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} PING FAILED. Check IP address and if the Pi is online. (0x00003)"
# Allow time for the user to see the error message. 
	sleep 3s
fi
done 