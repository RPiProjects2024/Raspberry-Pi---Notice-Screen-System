#!/bin/bash
# Raspberry Pi Management System - Mass Command Application.
# Version 1.0 - Created by Nick B, 2022.
# Use this after edits to COMPILE Properly: sed -i -e 's/\r$//' NoticeScreenManagementSystemMass.bash

# ------------------------------------------------------------------------------------------------
# This script and its code have been designed to function as part of the notice screen system. 
# Modifying or changing the code and or files stored could cause problems. 
# If you wish to make changes, do so at your own risk.
# If you need to change Management System Parameters, see line 42.
# ------------------------------------------------------------------------------------------------

# Command line colors:
	RED='\033[1;31m'
	WHITE='\033[1;37m'
	GREEN='\033[1;32m'

# Global Variables:
	VERSION="1.0"  																	# Version number. Used in echo strings.
	CMDACTIONS="-y" 																# Default CMD line action for automation.
	PICOMMANDDONE="1" 																# Static value is 0. DO NOT CHANGE!
	CURRENTHOSTIP=$(hostname -I)													# Management system IP address. Used for SCP transfers.
	AUTOSTARTTEMPURL="www.google.com"												# The default URL which is updated in the template file.
	AUTOSTARTLOC="/home/pi/RPNSMS/ASSETS/autostart"    								# Where the LXsession folder must go (used by IF statement).
	VIDEOLOC="/home/pi/RPNSMS/ASSETS/Video/display.desktop" 						# Where the VIDEO Function folder must go (used by IF statement).
	SLIDESHOWLOC="/home/pi/RPNSMS/ASSETS/Pictures/autostart"  						# Where the SLIDESHOW Function folder must go (used by IF statement).
	SLIDESHOWDEFAULTTIMER="12"														# The default slideshow timer which is updated in the template file for slideshows.
	SLIDESHOWTIMERSET="1"															# Loop until the IF statement is correctly matched.
	AUDIOLOC="/home/pi/RPNSMS/ASSETS/Music/display.desktop" 						# Where the AUDIO Function folder must go (used by IF statement).
	SEDAUTOSTARTLOC="/home/pi/RPNSMS/ASSETS/autostart" 								# Where the LXsession folder must go (used by SED script).
	PICLONEFOLDERLOC="/home/pi/RPNSMS/ASSETS/TEMPCOPY"								# The location where files are stored (TEMP) for Pi Clones.
	PASSWORDCHECKLOOP="1" 															# Ensures the passwords for accessing Pi devices match.
	URLUPDATETASK="0" 																# Handles if URL copy/update jobs have completed correctly.
	URLSTRINGTYPED="1"																# Loop until the IF statement is correctly matched.
	RPNMASSSCRIPT="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash"	# Location of this script on the Management System.
	RPNSCRIPT="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash"					# Location of the single script on the Management System.
	RPNAUTOEXECSCRIPT="/home/pi/RPNSMS/autoexec.bash"								# The current date and time for logging purposes.
    YNOPTION="0"																	# Used to determine yes or no selections.
	MESSAGETIMERSET="1"																# Loop until the IF statement is correctly matched.
	MESSAGESTRINGTYPED="1"															# Loop until the IF statement is correctly matched.
	DISKCHOICESELECTION="1"															# Used to close disk selection loop.

# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log

# Management System Parameters:
	PIUSER="pi" # Username for accessing Raspberry Pi devices. Default is pi.

# Delete the TEMP folder on launch
	sudo rm -r /home/pi/RPNSMS/ASSETS/TEMPCOPY &> /dev/null

# Delete the setup script to prevent accidental changes to the configuration.
	sudo rm -r RPNSMServerInstaller1.0.bash &> /dev/null
	clear
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager - Mass Command Application. ${GREEN}Version: $VERSION ${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "${RED}A maximum of 10 Pi screens can be changed.${WHITE} If the value is less than"
	echo "10 Pi devices, just press ENTER to skip until 10-10 is reached."
	echo -e "${GREEN}Type EXIT to return to the main menu.${WHITE}"
	echo -e "${GREEN}Please type IP layout to save typing the whole IP Address"
	echo -e "Example: 192.168.0. <Include the . like shown. ${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"

# Get the user to type the first 3 numbers of the IP Address. This saves typing the whole
# IP RANGE each time.	
	read IPADDLAYOUT

# If the IPADDLAYOUT is blank, return to the AUTOEXEC script.
if [[ -z "$IPADDLAYOUT" ]]; then
	
# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"	
		
fi

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $IPADDLAYOUT == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else


# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $IPADDLAYOUT == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else

	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}1-10"
# Get IP 1-10.
	read IPADD1
	IPADD1=$IPADDLAYOUT$IPADD1
	printf "\n"
	
# Get IP 2-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}2-10"
	read IPADD2
	IPADD2=$IPADDLAYOUT$IPADD2
	printf "\n"
	
# Get IP 3-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}3-10"
	read IPADD3
	IPADD3=$IPADDLAYOUT$IPADD3
	printf "\n"

# Get IP 4-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}4-10"
	read IPADD4
	IPADD4=$IPADDLAYOUT$IPADD4
	printf "\n"	

# Get IP 5-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}5-10"
	read IPADD5
	IPADD5=$IPADDLAYOUT$IPADD5
	printf "\n"
	
# Get IP 6-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}6-10"
	read IPADD6
	IPADD6=$IPADDLAYOUT$IPADD6
	printf "\n"
	
# Get IP 7-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}7-10"
	read IPADD7
	IPADD7=$IPADDLAYOUT$IPADD7
	printf "\n"
	
# Get IP 8-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}8-10"
	read IPADD8
	IPADD8=$IPADDLAYOUT$IPADD8
	printf "\n"
	
# Get IP 9-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}9-10"
	read IPADD9
	IPADD9=$IPADDLAYOUT$IPADD9
	printf "\n"
	
# Get IP 2-10.
	echo -e "${WHITE}Please type the last digits of the IP Address.${WHITE} ${GREEN}10-10"
	read IPADD10
	IPADD10=$IPADDLAYOUT$IPADD10	
	printf "\n"	

# If any entries were left blank, set the IP variables to 0.0.0..
if [ -z "$IPADD1" ]
then

	  IPADD1="0.0.0.0"	
fi

if [ -z "$IPADD2" ]
then

	  IPADD2="0.0.0.0"	
fi

if [ -z "$IPADD3" ]
then

	  IPADD3="0.0.0.0"	
fi

if [ -z "$IPADD4" ]
then

	  IPADD4="0.0.0.0"	
fi

if [ -z "$IPADD5" ]
then

	  IPADD5="0.0.0.0"	
fi

if [ -z "$IPADD6" ]
then

	  IPADD6="0.0.0.0"	
fi

if [ -z "$IPADD7" ]
then

	  IPADD7="0.0.0.0"	
fi

if [ -z "$IPADD8" ]
then

	  IPADD8="0.0.0.0"	
fi

if [ -z "$IPADD9" ]
then

	  IPADD9="0.0.0.0"	
fi

if [ -z "$IPADD10" ]
then

	  IPADD10="0.0.0.0"	
fi

# Ask for the password to use.
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Username being used: ${GREEN}$PIUSER ${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	printf "\n"
	echo "Type the password for accessing all specified Notice Pi screens:"
	read -s PIPASSWORD
	printf "\n"

# This is a long set of IF statements. This was done to show the operator EACH IP address
# authentication and know if typed IP addresses and passwords worked.

# Simple way to check the password/IP address are actually correct. IP 1-10.
	echo -e "+ Logging in... @ $IPADD1 [1-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 echo "Connection successful." &> /dev/null
	AUTHCHECK1=$?
	
if [ $AUTHCHECK1 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi	
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 2-10.
	echo -e "+ Logging in... @ $IPADD2 [2-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 echo "Connection successful." &> /dev/null
	AUTHCHECK2=$?
	
if [ $AUTHCHECK2 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 3-10.
	echo -e "+ Logging in... @ $IPADD3 [3-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 echo "Connection successful." &> /dev/null
	AUTHCHECK3=$?
	
if [ $AUTHCHECK3 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 4-10.
	echo -e "+ Logging in... @ $IPADD4 [4-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 echo "Connection successful." &> /dev/null
	AUTHCHECK4=$?
	
if [ $AUTHCHECK4 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 5-10.
	echo -e "+ Logging in... @ $IPADD5 [5-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 echo "Connection successful." &> /dev/null
	AUTHCHECK5=$?
	
if [ $AUTHCHECK5 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 6-10.
	echo -e "+ Logging in... @ $IPADD6 [6-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 echo "Connection successful." &> /dev/null
	AUTHCHECK6=$?
	
if [ $AUTHCHECK6 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 7-10.
	echo -e "+ Logging in... @ $IPADD7 [7-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 echo "Connection successful." &> /dev/null
	AUTHCHECK7=$?
	
if [ $AUTHCHECK7 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 8-10.
	echo -e "+ Logging in... @ $IPADD8 [8-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 echo "Connection successful." &> /dev/null
	AUTHCHECK8=$?
	
if [ $AUTHCHECK8 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 9-10.
	echo -e "+ Logging in... @ $IPADD9 [9-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 echo "Connection successful." &> /dev/null
	AUTHCHECK9=$?
	
if [ $AUTHCHECK9 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi
printf "\n"

# Simple way to check the password/IP address are actually correct. IP 10-10.
	echo -e "+ Logging in... @ $IPADD10 [10-10]"

	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 echo "Connection successful." &> /dev/null
	AUTHCHECK10=$?
	
if [ $AUTHCHECK10 == 0 ]; then	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-LOGIN):" "The management system was able to login to the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} IP & password OK."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-LOGIN):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"	
fi

sleep 2s

# ------------------------------------------------------------------------------------------------------------
# Start of Management system.

# Ask the user to choose an option.
	clear
	echo "+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager - Mass Command Application. ${GREEN}Version: $VERSION ${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Username:${WHITE} $PIUSER"
	echo -e "Please choose one of the following options:"
	echo "+---------------------------------------------------------------------------+"

# List values:	
	options=("Update notice screen URL" "Play Video" "Play Slideshow" "Play Audio" "Copy USB upload" "Update and upgrade Pi" "Clone Notice Screen" "Delete Content" "Restart Pi" "Shutdown Pi" "Restart Application" "Display Message" "Exit")
select opt in "${options[@]}"
do
    case $opt in
        "Update notice screen URL")
	echo "+---------------------------------------------------------------------------+"
	echo "Update multiple notice screen URLs:"
	echo "+---------------------------------------------------------------------------+"

while [ $URLSTRINGTYPED -gt 0 ]; do
	echo "Type the URL you wish update on the Pi Notice Screens"
	echo -e "Example: ${GREEN}SERVER-NAME/index.html${WHITE}"
	read URLUPDATE

if [ -z "$URLUPDATE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The URL was left blank!"
else

# Option to enable AUDIO for specific modes where Audio can be used together.
# MASS MODE Script:

	printf "\n"
	echo -e "+ Would you also like to enable audio playback with this mode?"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac


# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] Audio will be enabled..."
	ENABLEAUDIO="1"

else

	echo -e "+ [OK] Audio will not be enabled..."
	ENABLEAUDIO="0"
fi


	echo "+ Please wait..."	

	printf "\n"
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (1-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD1:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (2-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD2:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (3-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD3:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (4-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD4:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (5-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD5:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (6-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD6:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (7-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD7:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (8-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD8:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (9-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD9:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (10-10)
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/autostart pi@$IPADD10:/home/pi/.config/lxsession/LXDE-pi &> /dev/null	


# Remove audio/video playback (used to restore just notice screen functionality). 1-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD1"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 2-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD2"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 3-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD3"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 4-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD4"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 5-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD5"
	printf "\n"

# Remove audio/video playback (used to restore just notice screen functionality). 6-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD6"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 7-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD7"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 8-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD8"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 9-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD9"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 10-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD10"
	printf "\n"

# Modify the autostart template file on the Management system.
	echo "+ Please wait..."
	sudo sed -i -- 's#'"$AUTOSTARTTEMPURL"'#'"$URLUPDATE"'#g' "$SEDAUTOSTARTLOC"
	SEDCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SEDCOPYOUTPUT == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
else
	URLUPDATETASK="0"
fi

	printf "\n"
# Use SCP to transfer updated autoboot file.
# PI IP Address 1
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD1:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT1=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT1 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD1"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD1."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 2
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD2:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT2=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT2 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD2"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD2."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 3
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD3:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT3=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT3 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD3"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD3."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 4
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD4:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT4=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT4 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD4"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD4."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 5
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD5:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT5=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT5 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD5"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD5."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 6
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD6:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT6=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT6 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD6"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD6."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 7
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD7:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT7=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT7 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD7"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD7."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 8
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD8:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT8=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT8 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD8"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD8."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 9
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD9:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT9=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT9 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD9"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD9."
	URLUPDATETASK="0"
fi
	printf "\n"

# PI IP Address 10
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUTOSTARTLOC $PIUSER@$IPADD10:/home/pi/.config/lxsession/LXDE-pi
	SSHCOPYOUTPUT10=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHCOPYOUTPUT10 == 0 ]; then
	((URLUPDATETASK=URLUPDATETASK+1))
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-URL):" "The URL has been updated to:" "$URLUPDATE" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The template URL was successfully uploaded on $IPADD10"
	echo -e "+${GREEN} [OK]${WHITE} Updated URL."
	else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-URL):" "The autostart script failed to copy from the management system. Skipped!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Template upload failed. Incorrect IP / password or left blank! This will be skipped (0x00004) @ $IPADD10."
	URLUPDATETASK="0"
fi
	printf "\n"
		
# Now replace the ORIGINAL autostart template on the Management system.
	sudo cp -r /home/pi/RPNSMS/ASSETS/autostartbak/autostart /home/pi/RPNSMS/ASSETS
	AUTOSTARTTEMPTASK=$?

# Check the template autostart file has copied back to the Management system.
if [ -f "$AUTOSTARTLOC" ]; then
	echo -e "+${GREEN} [OK]${WHITE} Management system autostart file reset."
	((URLUPDATETASK=URLUPDATETASK+1))
else
	echo -e "!${RED} [FAIL]${WHITE} Management system autostart file failed to copy or does not exist!"
	URLUPDATETASK="0"
exit
fi
	printf "\n"

# Check if the user wanted to enable Audio playback:
if [ $ENABLEAUDIO == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Enabling Audio..."

# Adding the Audio mode (Must be placed after the selected mode has been applied):

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop

# Add Audio support to Notice screens:

	echo "+ Set permissions to copy the required file. [1-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo chmod 777 /etc/xdg/autostart

	echo "+ Set permissions to copy the required file. [2-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [3-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [4-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [5-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [6-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo chmod 777 /etc/xdg/autostart

	echo "+ Set permissions to copy the required file. [7-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [8-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [9-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [10-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo chmod 777 /etc/xdg/autostart


# ------START COPY PROCEDURE ------


# Use SCP to transfer updated autoboot file. [1-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD1:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT1=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT1 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD1"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi

# Use SCP to transfer updated autoboot file. [2-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD2:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT2=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT2 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD2"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [3-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD3:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT3=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT3 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD3"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi

# Use SCP to transfer updated autoboot file. [4-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD4:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT4=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT4 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD4"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [5-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD5:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT5=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT5 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD5"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [6-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD6:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT6=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT6 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD6"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [7-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD7:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT7=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT7 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD7"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [8-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD8:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT8=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT8 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD8"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [9-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD9:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT9=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT9 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD9"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [10-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD10:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT10=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT10 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD10"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"
	
	printf "\n"	

fi


else

	printf "\n"
	echo -e "+ ${GREEN}[OK]${WHITE} Audio was not selected to be enabled at this time."
	printf "\n"
fi


	echo "+ Restarting Pi Notice Screens..."
# Pi 1-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -r now &> /dev/null
# Pi 2-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
# Pi 3-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
# Pi 4-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
# Pi 5-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
# Pi 6-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
# Pi 7-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
# Pi 8-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
# Pi 9-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
# Pi 10-10 restart command.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ [OK] Reset commands were sent."	
	sleep 5s 

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-URL):" "+-----------------URL update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"	
			break			
fi
done
            ;;
			
# Play Video or Audio

        "Play Video")
	echo "+---------------------------------------------------------------------------+"
	echo "Play Video:"
	echo "+---------------------------------------------------------------------------+"
	echo "This will enable video output on the target Raspberry Pi devices."
	echo -e "${GREEN}Supported audio & video files: .mp4 .avi"
	echo "Use the following name formats for an order: 1.Video.mp4 2.Video.mp4 etc..."
	echo -e "${RED}Place files in the following location on each Pi: /home/pi/Videos"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable audio/video playback, please choose 'Update notice screen URL'${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Delete the Notice Screen start up file. Pi 1
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD1"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 2
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD2"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 3
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD3"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 4
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD4"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 5
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD5"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 6
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD6"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 7
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD7"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 8
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD8"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 9
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD9"
	printf "\n"
	
# Delete the Notice Screen start up file. Pi 10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo rm /home/pi/.config/lxsession/LXDE-pi/autostart &> /dev/null
	echo "+ Deleting Notice screen start up script... @ $IPADD10"
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 1.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD1:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT1=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT1 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD1"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD1"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 2.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD2:/etc/xdg/autostart &> /dev/null 
	SSHAUDIOVIDEOCOPYOUTPUT2=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT2 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD2"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD2"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 3.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD3:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT3=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT3 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD3"
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD3"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 4.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD4:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT4=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT4 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD4"
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD4"
fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 5.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD5:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT5=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT5 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD5"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD5"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 6.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD6:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT6=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT6 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD6"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD6"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 7.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD7:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT7=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT7 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD7"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD7"

fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 8.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD8:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT8=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT8 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD8"
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD8"
fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 9.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD9:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT9=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT9 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD9"
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD9"
fi
	printf "\n"

# Use SCP to transfer updated autoboot file. Pi 10.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $VIDEOLOC $PIUSER@$IPADD10:/etc/xdg/autostart &> /dev/null
	SSHAUDIOVIDEOCOPYOUTPUT10=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOVIDEOCOPYOUTPUT10 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-VIDEO):" "The management system was able to enable video playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Video playback has been enabled @ $IPADD10"
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-VIDEO):" "The management system Failed to enable Video playback! (0x00004)!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Video playback! (0x00004) @ $IPADD10"
fi
	printf "\n"

# Restart all Raspberry Pi devices.
	echo -e "Rebooting Pi @ $IPADD1"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD2"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD3"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD4"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD5"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD6"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD7"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD8"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD9"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD10"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+${GREEN} [OK]${WHITE} The Video commands were sent."
# Add delay timer to show finished message.
	sleep 5s

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-VIDEO):" "+-----------------VIDEO update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"


else
	exec "$RPNAUTOEXECSCRIPT"
fi
		
            ;;
						
	# Play Audio

        "Play Audio")
	echo "+---------------------------------------------------------------------------+"
	echo "Play Audio:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}(If the Pi is set to play Videos, update the URL first, before adding audio!)${WHITE}"
	echo "This will enable audio output in the background on the target Raspberry Pi"
	echo "devices and play while the Notice screen is running."
	echo -e "${GREEN}Supported audio: .wav .mp3 .ogg"
	echo "Use the following name formats for an order: 1.Song1.mp3 2.Song2.mp3 etc..."
	echo -e "${RED}Place files in the following location on this Pi: /home/pi/Music"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable audio playback, please choose 'Update notice screen URL'${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# [1-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD1:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT1=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT1 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD1"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD1"
fi	
	printf "\n"

# [2-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD2:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT2=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT2 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD2"		
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD2"
fi		
	printf "\n"

# [3-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD3:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT3=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT3 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD3"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD3"
fi
	printf "\n"
	
# [4-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD4:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT4=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT4 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD4"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD4"
fi	
	printf "\n"

# [5-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD5:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT5=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT5 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD5"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD5"
fi	
	printf "\n"

# [6-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD6:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT6=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT6 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD6"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD6"
fi
	printf "\n"

# [7-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD7:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT7=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT7 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD7"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD7"
fi
	printf "\n"

# [8-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD8:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT8=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT8 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD8"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD8"
fi
	printf "\n"

# [9-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD9:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT9=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT9 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD9"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD9"
fi
	printf "\n"

# [10-10]

# Use SCP to transfer updated autoboot file. 
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD10:/etc/xdg/autostart &> /dev/null
	SSHAUDIOCOPYOUTPUT10=$?

# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHAUDIOCOPYOUTPUT10 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD10"
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-AUDIO):" "The management system failed to enable audio playback! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004) This will be skipped. @ $IPADD10"
fi	
	printf "\n"

# Restart all Raspberry Pi devices.
	echo -e "Rebooting Pi @ $IPADD1"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD2"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD3"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD4"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD5"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD6"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD7"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD8"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD9"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD10"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+${GREEN} [OK]${WHITE} The Audio commands were sent."
	sleep 5s

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-AUDIO):" "+-----------------AUDIO update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
            ;;			
			
       "Update and upgrade Pi")
	printf "\n"
	echo "+---------------------------------------------------------------------------+"
    echo "Update and upgrade multiple Raspberry Pi systems:"
	echo "+---------------------------------------------------------------------------+"

printf "\n"

# [PI 1-10]
# Update the Raspberry Pi device (1-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD1... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo apt-get -y update &> /dev/null
	PIUPDATETASK1=$?
	
# Check the output of the update command (1-10).			
if [ $PIUPDATETASK1 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD1."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD1."
fi

# Upgrade the Raspberry Pi devices (1-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD1... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo apt-get -y upgrade &> /dev/null
	PIUPGRADETASK1=$?
	
# Check the output of the upgrade command (1-10).			
if [ $PIUPGRADETASK1 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD1."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @$IPADD1."
fi
	printf "\n"

# [PI 2-10]
# Update the Raspberry Pi device (2-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD2... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo apt-get update -y &> /dev/null
	PIUPDATETASK2=$?
	
# Check the output of the update command (2-10).			
if [ $PIUPDATETASK2 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD2."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD2."
fi

# Upgrade the Raspberry Pi devices (2-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD2... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK2=$?
	
# Check the output of the upgrade command (2-10).			
if [ $PIUPGRADETASK2 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @$IPADD2."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @$IPADD2."
fi
	printf "\n"

# [PI 3-10]
# Update the Raspberry Pi device (3-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD3... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo apt-get update -y &> /dev/null
	PIUPDATETASK3=$?
	
# Check the output of the update command (3-10).			
if [ $PIUPDATETASK3 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD3."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD3."
fi

# Upgrade the Raspberry Pi devices (3-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD3... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK3=$?
 	
# Check the output of the upgrade command (3-10).			
if [ $PIUPGRADETASK3 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @$IPADD3."	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @$IPADD3."
fi
	printf "\n"

# [PI 4-10]
# Update the Raspberry Pi device (4-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD4... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo apt-get update -y &> /dev/null
	PIUPDATETASK4=$?
	
# Check the output of the update command (4-10).			
if [ $PIUPDATETASK4 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD4."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD4."
fi

# Upgrade the Raspberry Pi devices (4-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD4... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK4=$?
		
# Check the output of the upgrade command (4-10).			
if [ $PIUPGRADETASK4 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD4."	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD4."
fi
	printf "\n"

# [PI 5-10]
# Update the Raspberry Pi device (5-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD5... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo apt-get update -y &> /dev/null
	PIUPDATETASK5=$?
	
# Check the output of the update command (5-10).			
if [ $PIUPDATETASK5 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD5."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD5."
fi

# Upgrade the Raspberry Pi devices (5-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD5... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK5=$?
	
# Check the output of the upgrade command (5-10).			
if [ $PIUPGRADETASK5 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD5."	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD5."
fi
	printf "\n"

# [PI 6-10]
# Update the Raspberry Pi device (6-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD6... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo apt-get update -y &> /dev/null
	PIUPDATETASK6=$?
	
# Check the output of the update command (6-10).			
if [ $PIUPDATETASK6 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD6."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD6."
fi

# Upgrade the Raspberry Pi devices (6-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD6... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK6=$?
 
# Check the output of the upgrade command (6-10).			
if [ $PIUPGRADETASK6 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD6."	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD6."
fi
	printf "\n"

# [PI 7-10]
# Update the Raspberry Pi device (7-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD7... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo apt-get update -y &> /dev/null
	PIUPDATETASK7=$?
	
# Check the output of the update command (7-10).			
if [ $PIUPDATETASK7 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD7."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD2."
fi

# Upgrade the Raspberry Pi devices (7-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD7... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK7=$?
	
# Check the output of the upgrade command (7-10).			
if [ $PIUPGRADETASK7 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD7."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD7."
fi
	printf "\n"

# [PI 8-10]
# Update the Raspberry Pi device (8-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD8... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo apt-get update -y &> /dev/null
	PIUPDATETASK8=$?
	
# Check the output of the update command (8-10).			
if [ $PIUPDATETASK8 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD8."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD8."
fi

# Upgrade the Raspberry Pi devices (8-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD8... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK8=$?
	
# Check the output of the upgrade command (8-10).			
if [ $PIUPGRADETASK8 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD8."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Upgrade failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD8."
fi
	printf "\n"

# [PI 9-10]
# Update the Raspberry Pi device (9-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD9... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo apt-get update -y &> /dev/null
	PIUPDATETASK9=$?
	
# Check the output of the update command (9-10).			
if [ $PIUPDATETASK9 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD9."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD9."
fi

# Upgrade the Raspberry Pi devices (9-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD9... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK9=$?
	
# Check the output of the upgrade command (9-10).			
if [ $PIUPGRADETASK9 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD9."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD9."
fi
	printf "\n"

# [PI 10-10]
# Update the Raspberry Pi device (10-10).
	echo "+ Updating Raspberry Pi OS @ $IPADD10... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo apt-get update -y &> /dev/null
	PIUPDATETASK10=$?
	
# Check the output of the update command (10-10).			
if [ $PIUPDATETASK10 -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-UPDATE):" "The management system updated the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS update was successful @ $IPADD10."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-UPDATE):" "The management system failed to update the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD10."
fi

# Upgrade the Raspberry Pi devices (10-10).
	echo "+ Upgrading Raspberry Pi OS @ $IPADD10... (This may take a while)"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo apt-get upgrade -y &> /dev/null
	PIUPGRADETASK10=$?
	
# Check the output of the upgrade command (10-10).			
if [ $PIUPGRADETASK10 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-UPGRADE):" "The management system upgraded the Raspberry Pi." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi OS upgrade was successful @ $IPADD10."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-UPGRADE):" "The management system failed to upgrade the Raspberry Pi!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Update failed! Incorrect IP / password or left blank! This will be skipped @ $IPADD10."
fi
	printf "\n"

# Pi update and upgrade commands have been sent.
	echo -e "+${GREEN} [OK]${WHITE} The Raspberry Pi update-upgrade commands were sent"
	echo -e "+${GREEN} [WARN]${WHITE} A reboot of all Pi devices is advised."
# Leave enough time to read the status of the remaining update status.
	sleep 8s
	
# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"
            ;;

# Clone Notice Screen devices

        "Clone Notice Screen")
	echo "+---------------------------------------------------------------------------+"
	echo "Clone Notice Screen devices:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "This will clone ${GREEN}'$IPADD1's${WHITE} VIDEO, PICTURES & MUSIC folder"
	echo -e "to the following Raspberry Pi devices:"
	echo -e "${GREEN}-+ $IPADD2"
	echo -e "${GREEN}-+ $IPADD3"
	echo -e "${GREEN}-+ $IPADD4"
	echo -e "${GREEN}-+ $IPADD5"
	echo -e "${GREEN}-+ $IPADD6"
	echo -e "${GREEN}-+ $IPADD7"
	echo -e "${GREEN}-+ $IPADD8"
	echo -e "${GREEN}-+ $IPADD9"
	echo -e "${GREEN}-+ $IPADD10"	
	echo -e "${RED}DANGER! Any existing videos, pictures and music will be deleted!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to continue.
if [ $YNOPTION -eq 1 ]; then

	echo -e "Continuing with CLONE procedure" &> /dev/null

else
	exec "$RPNAUTOEXECSCRIPT"
fi

# Ask if the Management System should also apply the same mode(s) as the PI to clone:
echo -e "Do you wish to apply the same mode as $IPADD1?"
echo -e "Typing no will simply clone just the files."
read -p "Apply the same mode? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	APPLYSAMEPIMODE="1" # This will make the Management system apply the same mode as the Pi to clone.
	echo -e "[OK] The Management system will apply the same mode as $IPADD1."
	printf "\n"
else
	APPLYSAMEPIMODE="0"	# This will make the Management system only copy the files.
	echo -e "[OK] The Management system will not apply the same mode as $IPADD1."
	printf "\n"
fi
	
# Delete the existing TEMP folder to copy the EXACT files from Pi 1.
	echo "+ Deleting existing TEMP folder on the Management system..."
	sudo rm -r /home/pi/RPNSMS/ASSETS/TEMPCOPY &> /dev/null	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The TEMP folder has been deleted from the management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+ ${GREEN}[OK]${WHITE} The TEMP folder has been removed."
	printf "\n"
	
# Create directory on the Remote Pi (This is used to copy the temp files).
	echo "+ Creating TEMP directory for clone process..."
	sudo mkdir /home/pi/RPNSMS/ASSETS/TEMPCOPY &> /dev/null	

# Create CurrentMode Directory for applying the same mode to Pi devices to clone:
	sudo mkdir /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The TEMP folder has been created on the management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+ ${GREEN}[OK]${WHITE} The TEMP folder has been created."
	printf "\n"
	
# Copy the VIDEOS folder to the Management system.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "Downloading the Videos folder from '$IPADD1' to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Downloading the Videos folder from '$IPADD1' to the Management system..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/home/pi/Videos /home/pi/RPNSMS/ASSETS/TEMPCOPY 
	PICLONEVIDEOCOPYMS=$?
	
# Check that the copy job completed without errors.			
if [ $PICLONEVIDEOCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Videos folder from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Video folder has been copied to the Management System."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Videos folder from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to transfer the Video folder! (0x00009)"
fi
	printf "\n"

# Copy the PICTURES folder to the Management system.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "Downloading the Pictures folder from '$IPADD1' to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Downloading the Pictures folder from '$IPADD1' to the Management system..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/home/pi/Pictures /home/pi/RPNSMS/ASSETS/TEMPCOPY 
	PICLONEPICTURESCOPYMS=$?
	
# Check that the copy job completed without errors.			
if [ $PICLONEPICTURESCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Pictures folder from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Pictures folder has been copied to the Management System."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Pictures folder from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to transfer the Pictures folder! (0x00009)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the Management system.
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "Downloading the Music folder from '$IPADD1' to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Downloading the Music folder from '$IPADD1' to the Management system..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/home/pi/Music /home/pi/RPNSMS/ASSETS/TEMPCOPY 
	PICLONEMUSICCOPYMS=$?
	
# Check that the copy job completed without errors.			
if [ $PICLONEMUSICCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Music folder from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Music folder has been copied to the Management System."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Music folder from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to transfer the music folder! (0x00009)"
fi
	printf "\n"
	

# [Pi 2-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log
	
# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD2'...[2-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD2:/home/pi/
	PI1VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI1VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD2."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD2. (0x00004)"
fi
	printf "\n"
	
# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD2'...[2-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD2:/home/pi/
	PI1PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI1PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD2."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD2. (0x00004)"
fi
	printf "\n"	

	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD2'...[2-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD2:/home/pi/
	PI1VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI1VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD2."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD2. (0x00004)"
fi
	printf "\n"
	
# [Pi 3-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log
	
# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD3'...[3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD3:/home/pi/
	PI2VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI2VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD3."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD3. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD3'...[2-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD3:/home/pi/
	PI2PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI2PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD3."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD3. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD3'...[3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD3:/home/pi/
	PI2VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI2VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD3."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD3. (0x00004)"
fi
	printf "\n"
	
# [Pi 4-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm -f /home/pi/Pictures/*
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD4'...[4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD4:/home/pi/
	PI3VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI3VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD4."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD4. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD4'...[4-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD4:/home/pi/
	PI3PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI3PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD4."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD4. (0x00004)"
fi
	printf "\n"

# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD4'...[4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD4:/home/pi/
	PI3MUSICCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI3MUSICCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD4."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD4. (0x00004)"
fi
	printf "\n"

# [Pi 5-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log
	
# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD5'...[5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD5:/home/pi/
	PI4VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI4VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD5."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD5. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD5'...[5-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD5:/home/pi/
	PI4PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI4PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD5."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD5. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD5'...[5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD5:/home/pi/
	PI4AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI4AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD5."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD5. (0x00004)"
fi
	printf "\n"

# [Pi 6-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD6'...[6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD6:/home/pi/
	PI5VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI5VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD6."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD6. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD6'...[6-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD6:/home/pi/
	PI5PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI5PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD6."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD6. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD6'...[6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD6:/home/pi/
	PI5AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI5AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD6."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD6. (0x00004)"
fi
	printf "\n"
	
	
# [Pi 7-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD7'...[7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD7:/home/pi/
	PI6VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI6VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD7."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD7."
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD7'...[7-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD7:/home/pi/
	PI6PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI6PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD7."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD7. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD7'...[7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD7:/home/pi/
	PI6AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI6AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD7."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD7. (0x00004)"
fi
	printf "\n"
	
# [Pi 8-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD8'...[8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD8:/home/pi/
	PI7VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI7VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD8."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD8. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD8'...[8-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD8:/home/pi/
	PI6PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI6PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD8."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD8. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD8'...[8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD8:/home/pi/
	PI7AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI7AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD8."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD8. (0x00004)"
fi
	printf "\n"

# [Pi 9-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD9'...[9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD9:/home/pi/
	PI8VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI8VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD9."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD9. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD9'...[9-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD9:/home/pi/
	PI8PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI8PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD9."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD9. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD9'...[9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD9:/home/pi/
	PI8AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI8AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-CLONE):" "The Music folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD9."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD9. (0x00004)"
fi
	printf "\n"
	
# [Pi 10-10]
# Delete any existing files which may be in the videos folder.
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm -f /home/pi/Videos/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm -f /home/pi/Music/*
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm -f /home/pi/Pictures/*

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "Deleted all files in the Music, Picture and Video folder." >> /home/pi/RPNSMS/eventlog.log

# Copy the VIDEO folder to the target Raspberry Pi.
	echo "+ Uploading the VIDEOS folder to '$IPADD10'...[10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Videos pi@$IPADD10:/home/pi/
	PI9VIDEOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI9VIDEOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} VIDEO folder cloned to $IPADD10."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "The Video folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone VIDEO folder to $IPADD10. (0x00004)"
fi
	printf "\n"

# Copy the PICTURE folder to the target Raspberry Pi.
	echo "+ Uploading the PICTURES folder to '$IPADD10'...[10-10]" 
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /home/pi/RPNSMS/ASSETS/TEMPCOPY/Pictures pi@$IPADD10:/home/pi/
	PI9PICTURECOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI9PICTURECOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "The Pictures folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} PICTURES folder cloned to $IPADD10."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "The Pictures folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone PICTURES folder to $IPADD10. (0x00004)"
fi
	printf "\n"
	
# Copy the MUSIC folder to the target Raspberry Pi.
	echo "+ Uploading the MUSIC folder to '$IPADD10'...[10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/Music pi@$IPADD10:/home/pi/
	PI9AUDIOCOPY=$?
	
# Check that the copy job completed without errors.			
if [ $PI9AUDIOCOPY -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-CLONE):" "The Video folder has cloned from:" "$IPADD1" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} MUSIC folder cloned to $IPADD10."
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-CLONE):" "The Music folder failed to clone from:" "$IPADD1""! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to clone MUSIC folder to $IPADD10. (0x00004)"
fi
	printf "\n"

# Now check if the user wants to clone the same mode to the Raspberry Pi devices:
if [ $APPLYSAMEPIMODE -eq 1 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The current mode from '$IPADD1' will be applied to the clone procedure.." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+ ${GREEN}[OK]${WHITE} Applying $IPADD1's mode to the Notice screens..."

	printf "\n"

# Check what mode the Pi to clone is running:

# URL mode? (firefox-ESR)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'URL' (1-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSURL=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo pgrep -x "firefox-esr") &> /dev/null
	PISTATUSURLOUTPUT=$?

# Slideshow mode? (feh)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'SLIDESHOW' (2-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSSLIDESHOW=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo pgrep -x "feh") &> /dev/null
	PISTATUSSLIDESHOWOUTPUT=$?

# Video or Audio Mode? (vlc)
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(PI-INFO):" "Attempting to obtain Pi operation mode: 'VIDEO/AUDIO' (3-3)" >> /home/pi/RPNSMS/eventlog.log
	PISTATUSVLC=$(sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo pgrep -x "vlc") &> /dev/null
	PISTATUSVLCOUTPUT=$?

	printf "\n"

# Is the notice screen running in URL mode?
if [ $PISTATUSURLOUTPUT == 0 ]; then
	echo -e "+ URL Mode: ${GREEN}$IPADD1 is running in URL mode.${WHITE}"

	echo -e "+ Downloading the URL script file to the Management System..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/home/pi/.config/lxsession/LXDE-pi/autostart /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode 
	PICLONEURLCOPYMS=$?
if [ $PICLONEURLCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The URL mode script from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The URL mode script has been copied to the Management System."


	echo -e "+ Removing video playback from the Notice Screens..."


# Remove audio/video playback (used to restore just notice screen functionality). 2-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD2"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 3-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD3"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 4-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD4"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 5-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD5"
	printf "\n"

# Remove audio/video playback (used to restore just notice screen functionality). 6-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD6"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 7-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD7"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 8-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD8"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 9-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD9"
	printf "\n"
	
# Remove audio/video playback (used to restore just notice screen functionality). 10-10
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Disabled Video/audio playback. @ $IPADD10"
	printf "\n"	
	
# Now copy the updated URL from the Pi to clone:


# Restore URL script file to the Pi (Enabling video playback deletes it). (2-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [2-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD2:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (3-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD3:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (4-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD4:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (5-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD5:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (6-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD6:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (7-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD7:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (8-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD8:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

# Restore URL script file to the Pi (Enabling video playback deletes it). (9-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD9:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	
# Restore URL script file to the Pi (Enabling video playback deletes it). (10-10)
	echo -e "+ Attempting to transfer URL Script to Notice screens... [10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/autostart pi@$IPADD10:/home/pi/.config/lxsession/LXDE-pi &> /dev/null	
	printf "\n"	

else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The URL mode script from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to download the URL mode script to the Management System! (0x00009)"

fi	
	else
	echo -e "+ URL Mode: ${RED}$IPADD1 is not running in URL mode.${WHITE}"
fi

	printf "\n"

# Is the notice screen running in Video/Audio mode?
if [ $PISTATUSVLCOUTPUT == 0 ]; then
	echo -e "+ Video/Audio Mode: ${GREEN}$IPADD1 is running in Video/Audio mode.${WHITE}"

	echo -e "+ Downloading the Video/Audio script file to the Management System..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/etc/xdg/autostart/display.desktop /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode 
	PICLONEVIDEOAUDIOCOPYMS=$?
if [ $PICLONEVIDEOAUDIOCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Video/Audio mode script from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Video/Audio mode script has been copied to the Management System."

# Transfer the updated Video/Audio script file:

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [2-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD2:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [3-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD3:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [4-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD4:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [5-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD5:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [6-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD6:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [7-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD7:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [8-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD8:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [9-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD9:/etc/xdg/autostart &> /dev/null

	echo -e "+ Attempting to transfer Video/Audio Script to Notice screens... [10-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD10:/etc/xdg/autostart &> /dev/null

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo chmod 777 /etc/xdg/autostart

else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Video/Audio mode script from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to download the Video/Audio mode script to the Management System! (0x00009)"

fi

	else
	echo -e "+ Video/Audio Mode: ${RED}$IPADD1 is not running in Video/Audio mode.${WHITE}"
fi

	printf "\n"

# Is the notice screen running in Slideshow mode?
if [ $PISTATUSSLIDESHOWOUTPUT == 0 ]; then
	echo -e "Slideshow Mode: ${GREEN}$IPADD1 is running in Slideshow mode. ${WHITE}"

	echo -e "+ Downloading the Slideshow script file to the Management System..."
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no pi@$IPADD1:/home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode 
	PICLONESLIDESHOWCOPYMS=$?
if [ $PICLONESLIDESHOWCOPYMS -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Slideshow mode script from '$IPADD1' has been copied to the Management system." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Slideshow mode script has been copied to the Management System."

# Transfer the Slideshow script to the Pi devices:

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [2-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD2:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [3-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD3:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [4-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD4:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [5-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD5:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [6-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD6:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [7-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD7:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [8-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD8:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [9-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD9:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

	echo -e "+ Attempting to transfer Slideshow Script to Notice screens... [10-10]"
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no /home/pi/RPNSMS/ASSETS/TEMPCOPY/CurrentMode/display.desktop $PIUSER@$IPADD10:/home/pi/.config/lxsession/LXDE-pi &> /dev/null

else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The Slideshow mode script from '$IPADD1' failed to copy to the Management system! (0x00009)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE}Failed to download the Slideshow mode script to the Management System! (0x00009)"

fi
 
	else
	echo -e "+ Slideshow Mode: ${RED}$IPADD1 is not running in Slideshow mode. ${WHITE}"

# Reboot the Raspberry Pi devices:
	printf "\n"

	echo -e "+ Rebooting Notice screens:"
	printf "\n"


	echo -e "Rebooting Pi @ $IPADD2"		
	# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD3"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD4"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD5"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD6"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD7"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD8"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD9"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD10"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
fi


else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-CLONE):" "The current mode from '$IPADD1' will not be applied to the clone procedure.." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+ ${GREEN}[OK]${WHITE} The Management System will not clone $IPADD1's mode to the Notice screens..."

fi
	
# Clone complete. Display message.
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-CLONE):" "+-----------------CLONE update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

	printf "\n"

	echo "+---------------------------------------------------------------------------+"
	echo -e "+ ${GREEN}[OK]${WHITE} Clone operation completed:"
	echo -e "If any Notice Screens fail to apply the current mode from:"
	echo -e "'$IPADD1' use this error code for solutions: (0x00012)."
	echo "+---------------------------------------------------------------------------+"
	read -p "! Press any key to return to the main menu..."	


# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"
            ;;

        "Restart Pi")
	echo "+---------------------------------------------------------------------------+"
	echo -e "${RED}Restart multiple Raspberry Pi systems:${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${RED}WARNING! This command will be sent to all Raspberry Pi Devices!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Restart all Raspberry Pi devices.
	echo -e "+ Rebooting Pi @ $IPADD1"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD2"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD3"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD4"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD5"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD6"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD7"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD8"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD9"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "+ Rebooting Pi @ $IPADD10"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo "+ Restart commands were sent."
	sleep 5s

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"

else
# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"
fi

			break
            ;;
        "Shutdown Pi") 
	echo "+---------------------------------------------------------------------------+"
	echo -e "${RED}Shutdown multiple Pi systems:${WHITE}"
	echo "+---------------------------------------------------------------------------+"

	echo -e "${RED}WARNING! This command will be sent to all Raspberry Pi Devices!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Shutdown the Raspberry Pi.
	echo "+ Shutting down Raspberry Pi devices..."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD1 [1-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD2 [2-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD3 [3-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD4 [4-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD5 [5-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD6 [6-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD7 [7-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD8 [8-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD9 [9-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -h now &> /dev/null

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system sent a shutdown command." >> /home/pi/RPNSMS/eventlog.log
	echo -e "Shutting down Raspberry Pi $IPADD10 [10-10]"
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -h now &> /dev/null


	echo "+ Shutdown commands were sent."
	sleep 2s

# Restart the Management system.
	exec "$RPNAUTOEXECSCRIPT"
	break
else
	exec "$RPNAUTOEXECSCRIPT"
fi


			;;

# Play SlideShow

        "Play Slideshow")
	echo "+---------------------------------------------------------------------------+"
	echo "Play SlideShow:"
	echo "+---------------------------------------------------------------------------+"
	echo "This will enable a picture slideshow on the target Raspberry Pi devices."
	echo -e "${GREEN}Supported image files: .jpg .png .bmp .gif .tiff and many more."
	echo -e "${RED}Place pictures in the following location on this Pi: /home/pi/Pictures"
	echo -e "${GREEN}TIP: ${WHITE}Use the USB upload feature to make this easier to transfer."
	echo -e "${RED}To disable the Slideshow, please choose 'Update notice screen URL'${WHITE}"
	echo -e "${RED}or 'Play Video' from the management system.${WHITE}"

while [ $SLIDESHOWTIMERSET -gt 0 ]; do	
	printf "\n"
	echo -e "Type a number between: ${GREEN}5-3600 seconds${WHITE} to specify when"
	echo -e "the next picture should show on the screen:"
	read SLIDESHOWTIMERENTRY

if [[ "$SLIDESHOWTIMERENTRY" -ge 5 && "$SLIDESHOWTIMERENTRY" -lt 3601 ]]; then

	echo -e "${GREEN}[OK]${WHITE} $SLIDESHOWTIMERENTRY seconds will be applied to the Slideshow."
	SLIDESHOWTIMERSET="0"
	else
	echo -e "${RED}[ERROR]${WHITE} Please type a number between 5-3600 seconds."
fi

done	

# Option to enable AUDIO for specific modes where Audio can be used together.
# MASS MODE Script:

	printf "\n"
	echo -e "+ Would you also like to enable audio playback with this mode?"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] Audio will be enabled..."
	ENABLEAUDIO="1"

else

	echo -e "+ [OK] Audio will not be enabled..."
	ENABLEAUDIO="0"
fi


# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-SLIDESHOW):" "The management system applied $SLIDESHOWTIMERENTRY seconds to the Slideshow template." >> /home/pi/RPNSMS/eventlog.log

# Modify the autostart template file on the Management system.
	echo "+ Please wait..."
	sudo sed -i -- 's#'"$SLIDESHOWDEFAULTTIMER"'#'"$SLIDESHOWTIMERENTRY"'#g' "$SLIDESHOWLOC"
	SEDCOPYOUTPUT=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SEDCOPYOUTPUT == 0 ]; then
# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-SLIDESHOW):" "The management system modified the Slideshow template." >> /home/pi/RPNSMS/eventlog.log
	((SLIDESHOWTIMERUPDATECMD=SLIDESHOWTIMERUPDATECMD+1))
	echo -e "${GREEN}[OK]${WHITE} The Slideshow template has been modified."
else
	URLUPDATETASK="0"
# Event log entry:
		sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-SLIDESHOW):""The management system failed modify the Slideshow template! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
		echo -e "${RED}[ERROR]${WHITE} Unable to modify the Slideshow template. FATAL ERROR! (0x00004)"
		sleep 4s
		exec "$RPNAUTOEXECSCRIPT"
fi

	printf "\n"

# Add permissions to access the required file and folders.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Pictures/autostart
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo chmod 777 /home/pi/.config/lxsession/LXDE-pi &> /dev/null
	echo "+ Set permissions to copy the required file."

	printf "\n"	
	
# Delete the Notice Screen start up files.
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."	
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo rm /etc/xdg/autostart/display.desktop &> /dev/null
	echo "+ Deleting Notice screen start up script..."
	
	printf "\n"
	
# [1-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD1:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT1=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT1 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD1"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1""(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD1"
fi

# [2-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD2:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT2=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT2 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD2"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD2"
fi

# [3-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD3:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT3=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT3 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD3"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD3"
fi

# [4-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD4:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT4=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT4 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD4"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD4"
fi

# [5-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD5:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT5=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT5 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD5"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD5"
fi

# [6-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD6:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT6=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT6 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD6"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD6"
fi

# [7-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD7:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT7=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT7 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD7"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD7"
fi

# [8-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD8:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT8=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT8 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD8"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD8"
fi

# [9-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD9:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT9=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT9 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD9"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD9"
fi

# [10-10]
# Use SCP to transfer updated autoboot file.
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $SLIDESHOWLOC $PIUSER@$IPADD10:/home/pi/.config/lxsession/LXDE-pi &> /dev/null
	SSHSLIDESHOWCOPYOUTPUT10=$?
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHSLIDESHOWCOPYOUTPUT10 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SLIDESHOW):" "The management system was able to enable slideshow mode." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Slideshow mode has been enabled @ $IPADD10"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SLIDESHOW):" "The management system failed to enable Slideshow mode! (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable Slideshow mode! (0x00004) @ $IPADD10"
fi

# Now replace the ORIGINAL autostart template on the Management system.
	sudo cp -r /home/pi/RPNSMS/ASSETS/Pictures/bak/autostart /home/pi/RPNSMS/ASSETS/Pictures
	AUTOSTARTTEMPTASKSLIDESHOW=$?
	
# Check the template autostart file has copied back to the Management system.
if [ $AUTOSTARTTEMPTASKSLIDESHOW == 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MASS-SLIDESHOW):" "The management system slideshow template file has been reset." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Management system slideshow autostart file reset."
	((URLUPDATETASK=URLUPDATETASK+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$$CURRENTHOSTIP""(MASS-SLIDESHOW):" "The slideshow autostart template failed to reset!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Management system autostart file failed to copy or does not exist!"
	URLUPDATETASK="0"
exit
fi

	printf "\n"

# Check if the user wanted to enable Audio playback:
if [ $ENABLEAUDIO == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Enabling Audio..."

# Adding the Audio mode (Must be placed after the selected mode has been applied):

# Add permissions to access the required file and folder.
	sudo chmod 777 /home/pi/RPNSMS/ASSETS/Music/display.desktop

# Add Audio support to Notice screens:

	echo "+ Set permissions to copy the required file. [1-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 sudo chmod 777 /etc/xdg/autostart

	echo "+ Set permissions to copy the required file. [2-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [3-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [4-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [5-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [6-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 sudo chmod 777 /etc/xdg/autostart

	echo "+ Set permissions to copy the required file. [7-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [8-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [9-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 sudo chmod 777 /etc/xdg/autostart
	
	echo "+ Set permissions to copy the required file. [10-10]"
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 sudo chmod 777 /etc/xdg/autostart


# ------START COPY PROCEDURE ------


# Use SCP to transfer updated autoboot file. [1-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD1:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT1=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT1 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD1"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi

# Use SCP to transfer updated autoboot file. [2-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD2:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT2=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT2 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD2"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [3-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD3:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT3=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT3 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD3"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi

# Use SCP to transfer updated autoboot file. [4-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD4:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT4=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT4 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD4"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [5-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD5:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT5=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT5 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD5"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [6-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD6:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT6=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT6 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD6"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [7-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD7:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT7=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT7 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD7"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [8-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD8:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT8=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT8 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD8"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [9-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD9:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT9=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT9 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD9"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

fi


# Use SCP to transfer updated autoboot file. [10-10]
	sshpass -p $PIPASSWORD scp -r -o StrictHostKeyChecking=no $AUDIOLOC $PIUSER@$IPADD10:/etc/xdg/autostart
	SSHURLAUDIOVIDEOCOPYOUTPUT10=$?
	printf "\n"
# To ensure the URL copy/update completes, use an IF statement.
if [ $SSHURLAUDIOVIDEOCOPYOUTPUT10 == 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(AUDIO):" "The management system was able to enable audio playback." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Audio playback has been enabled @ $IPADD10"

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(AUDIO):" "The management system failed to enable audio playback. (0x00004)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to enable audio playback! (0x00004)"

	printf "\n"

fi


else

	printf "\n"
	echo -e "+ ${GREEN}[OK]${WHITE} Audio was not selected to be enabled at this time."
	printf "\n"

fi

# Restart all Raspberry Pi devices.
	echo -e "Rebooting Pi @ $IPADD1"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD2"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD3"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD4"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD5"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD6"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD7"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD8"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD9"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo -e "Rebooting Pi @ $IPADD10"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-SYSTEM):" "The management system attempted to send a restart command." >> /home/pi/RPNSMS/eventlog.log
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo shutdown -r now &> /dev/null
	echo "+ Reset command was sent."
	printf "\n"
	
	echo "+ Restart commands were sent."
	sleep 4s

# Task completed. Create line in log file.
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-SLIDESHOW):" "+-----------------SLIDESHOW update task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log

# Restart the Management system (Otherwise problems occur!)	
	exec "$RPNAUTOEXECSCRIPT"
			break

			;;
        "Restart Application")
            exec "$RPNMASSSCRIPT"
            ;;
        "Exit")
            exec "$RPNAUTOEXECSCRIPT" 
            ;;

        "Delete Content")
	echo "+---------------------------------------------------------------------------+"
	echo "Delete Content:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "This will ${RED}delete${WHITE} the contents of the ${RED}Music${WHITE}, ${RED}Video ${WHITE}and ${RED}Pictures ${WHITE}folder"
	echo -e "from the following Raspberry Pi devices:"
	echo -e "${RED}-+ $IPADD1"
	echo -e "${RED}-+ $IPADD2"
	echo -e "${RED}-+ $IPADD3"
	echo -e "${RED}-+ $IPADD4"
	echo -e "${RED}-+ $IPADD5"
	echo -e "${RED}-+ $IPADD6"
	echo -e "${RED}-+ $IPADD7"
	echo -e "${RED}-+ $IPADD8"
	echo -e "${RED}-+ $IPADD9"
	echo -e "${RED}-+ $IPADD10"	
	echo -e "${RED}This process is irreversible!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Begin the process:
	echo -e "+ Starting deletion process..."

# [Pi 1-10]

	echo -e "+ Checking connection @ $IPADD1"
	ping -c2 $IPADD1 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD1 [1-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD1 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 2-10]

	echo -e "+ Checking connection @ $IPADD2"
	ping -c2 $IPADD2 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD2 [2-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD2 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 3-10]

	echo -e "+ Checking connection @ $IPADD3"
	ping -c2 $IPADD3 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD3 [3-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD3 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 4-10]

	echo -e "+ Checking connection @ $IPADD4"
	ping -c2 $IPADD4 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD4 [4-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD4 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 5-10]

	echo -e "+ Checking connection @ $IPADD5"
	ping -c2 $IPADD5 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD5 [5-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD5 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi	

	printf "\n"
	
# [Pi 6-10]

	echo -e "+ Checking connection @ $IPADD6"
	ping -c2 $IPADD6 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD6 [6-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD6 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 7-10]

	echo -e "+ Checking connection @ $IPADD7"
	ping -c2 $IPADD7 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD7 [7-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD7 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"
	
# [Pi 8-10]

	echo -e "+ Checking connection @ $IPADD8"
	ping -c2 $IPADD8 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD8 [8-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD8 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 9-10]

	echo -e "+ Checking connection @ $IPADD9"
	ping -c2 $IPADD9 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD9 [9-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD9 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
fi

	printf "\n"

# [Pi 10-10]

	echo -e "+ Checking connection @ $IPADD10"
	ping -c2 $IPADD10 &> /dev/null

if [ $? -eq 0 ]; then   
	echo -e "+${GREEN} [OK]${WHITE} PING Passed!"

	echo "+ Starting deletion process... $IPADD10 [10-10]"
		
# Delete any existing files which may be in the videos folder.
	echo "+ Deleting the contents of the 'Videos' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm "/home/pi/Videos/*" &> /dev/null
# Delete any existing files which may be in the music folder.
	echo "+ Deleting the contents of the 'Music' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm "/home/pi/Music/*" &> /dev/null
# Delete any existing files which may be in the pictures folder.
	echo "+ Deleting the contents of the 'Pictures' folder..."
	sshpass -p $PIPASSWORD ssh $PIUSER@$IPADD10 sudo rm "/home/pi/Pictures/*" &> /dev/null
	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-DELETE CONTENT):" "Deleted all files in the Music, Pictures and Video folder." >> /home/pi/RPNSMS/eventlog.log

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(MASS-DELETE CONTENT):" "The management system was unable to connect. Incorrect IP or password! (0x00003)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "!${RED} [FAIL]${WHITE} Incorrect IP / password or left blank! This will be skipped. (0x00003)"
	fi
# Event log entry:
	sudo echo "$(date "+%D %T")" "(MASS-DELETE CONTENT):" "+-----------------MASS-DELETE CONTENT task completed.-----------------+" >> /home/pi/RPNSMS/eventlog.log
	
# Deletion job has completed:
echo -e "+ ${GREEN}[OK]${WHITE} The content deletion command has completed successfully."

sleep 3

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"


else

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
	
fi

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"

			break

            ;;

        "Display Message") 
	echo -e "+---------------------------------------------------------------------------+"
	echo -e  "${GREEN}Display Message${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "Use this to display a timed message on multiple Raspberry Pi screens."
	echo -e "The message will display over any open Windows."
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

# Specify the message time:
while [ $MESSAGETIMERSET -gt 0 ]; do	
	echo -e "Type a number between: ${GREEN}5-300 seconds${WHITE} to specify"
	echo -e "how long the message will show on screen:"
	read MESSAGETIMEENTRY
	printf "\n"

if [[ "$MESSAGETIMEENTRY" -ge 5 && "$MESSAGETIMEENTRY" -lt 301 ]]; then

	echo -e "${GREEN}[OK]${WHITE} $MESSAGETIMEENTRY seconds will be applied to the message."
	MESSAGETIMERSET="0"
	else
	echo -e "${RED}[ERROR]${WHITE} Please type a number between 5-300 seconds."
fi

done

while [ $MESSAGESTRINGTYPED -gt 0 ]; do
	echo "Type the message you want to display:"
	read PIMESSAGE

if [ -z "$PIMESSAGE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The message was left blank!"
else

# When a message is typed, end the loop to check for a value.
	MESSAGESTRINGTYPED="0"
	printf "\n"
fi
done

# Display Message on DISPLAY 0: on target Raspberry Pi (1-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [1-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD1 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT1=$?
	
if [ $PIMESSAGEOUTPUT1 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else

      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD1" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log

fi

# Display Message on DISPLAY 0: on target Raspberry Pi (2-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [2-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD2 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT2=$?
	
if [ $PIMESSAGEOUTPUT2 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else

      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD2" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (3-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [3-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD3 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT3=$?
	
if [ $PIMESSAGEOUTPUT3 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else

      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD3" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log

fi

# Display Message on DISPLAY 0: on target Raspberry Pi (4-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [4-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD4 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT4=$?
	
if [ $PIMESSAGEOUTPUT4 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else

      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD4" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (5-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [5-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD5 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT5=$?
	
if [ $PIMESSAGEOUTPUT5 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else

      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD5" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (6-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [6-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD6 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT6=$?
	
if [ $PIMESSAGEOUTPUT6 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD6" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (7-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [7-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD7 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT7=$?
	
if [ $PIMESSAGEOUTPUT7 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD7" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (8-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [8-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD8 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT8=$?
	
if [ $PIMESSAGEOUTPUT8 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD8" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (9-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [9-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD9 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT9=$?
	
if [ $PIMESSAGEOUTPUT9 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD9" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# Display Message on DISPLAY 0: on target Raspberry Pi (10-10):
	echo -e "+ Displaying message on Notice Screen with $MESSAGETIMEENTRY second timer... [10-10]"	
	sshpass -p $PIPASSWORD ssh -o StrictHostKeyChecking=no $PIUSER@$IPADD10 DISPLAY=:0 zenity --width=500 --height=200 --info --title "Message:" --text "'$PIMESSAGE'" --ok-label "'This will auto close in $MESSAGETIMEENTRY seconds...'" --timeout "'$MESSAGETIMEENTRY'" &> /dev/null &
	PIMESSAGEOUTPUT10=$?
	
if [ $PIMESSAGEOUTPUT10 == 0 ]; then	
# After the message has been broadcasted, return to the autoexec menu:
	echo -e "${GREEN}[OK]${WHITE} Sent display message to the notice screen."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(PI-MESSAGE-MASS):" "Displayed the following message on the desktop: $PIMESSAGE" >> /home/pi/RPNSMS/eventlog.log
	
else
      echo -e "${RED}[ERROR]${WHITE} Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped. (0x00003)"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$IPADD10" "(PI-MESSAGE-MASS):" "Failed to display the requested message to the target notice screen. Incorrect IP / password or left blank! This will be skipped!" >> /home/pi/RPNSMS/eventlog.log
	
fi

# All commands have been sent. Inform user and return to the autoexec menu.
	echo -e "+${GREEN} [OK]${WHITE} The message commands were sent."
	sleep 4
	exec "$RPNAUTOEXECSCRIPT"	


else
	exec "$RPNAUTOEXECSCRIPT"
fi
		;;

		"Copy USB upload")
	echo "+---------------------------------------------------------------------------+"
	echo "Upload content from USB:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${WHITE}Use this to upload media from a designated USB Storage device directly"
	echo -e "${WHITE}To a Notice screen. You must use the advanced options menu and "
	echo -e "${WHITE}select 'Setup USB Media Uploader' to configure a USB storage ${WHITE}"
	echo -e "device for compatibility before proceeding."
	echo "+---------------------------------------------------------------------------+"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ ${GREEN}Please connect a USB storage device to the Management System...${WHITE}"
	read -p "! Press any key when ready..."

	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s


while [ $DISKCHOICESELECTION -gt 0 ]; do
# Show connected devices:
	echo "+---------------------------------------------------------------------------+"
	lsblk	
	echo "+---------------------------------------------------------------------------+"
	echo -e "Type the NAME of the device you wish to use as a USB Media device."
	echo -e "${GREEN}To refresh, leave blank and press ENTER.${WHITE}"
	echo -e "${GREEN}NAME Example: ${WHITE}sda1${WHITE}"
	echo -e "Type EXIT to return to the main menu."
	read USBCLONESELECTION

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $USBCLONESELECTION == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $USBCLONESELECTION == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

if [ -z "$USBCLONESELECTION" ]
then
# Clear the screen to avoid confusion with the previous lsblk command.
	clear
	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s
else
	DISKCHOICESELECTION="0"
fi
done

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Confirm USB Media Storage device parameters!${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Please confirm the following details:${WHITE}"
	echo -e "+ Device NAME to use as Media upload device: $USBCLONESELECTION"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	sudo mount /dev/$USBCLONESELECTION /media &> /dev/null
	USBMOUNTOP=$?

if [ $USBMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Mounted: $USBCLONESELECTION successfully."


	# Define folder locations (event logging):
	USBHTMLLOC="/var/www/html"
	USBVIDEOSLOC="/media/Videos"
	USBPICTURESLOC="/media/Pictures"
	USBMUSICLOC="/media/Music"
	USBFOLDERMISSING="0" # An initial value is given to prevent an empty var, should folders already exists on the USB device.

# Option to enable HTML upload with USB:
# SINGLE MODE Script:

	printf "\n"
	echo -e "+ Would you also just like to upload HTML files?"
	echo -e "Note:${GREEN} HTML files will be uploaded to the Management System for use with Apache"
	echo -e "to the following location: '/var/www/html'.${WHITE}"
	read -p "(yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0";;
	* ) echo invalid response && YNOPTION="0";
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ [OK] HTML will be uploaded to the Management system..."
	UPLOADHTMLONLY="1"

else

	echo -e "+ [OK] HTML will be not be uploaded to the Management system..."
	UPLOADHTMLONLY="0"
fi

# Confirm the directories were created successfully:	
# Check if the HTML folder exists on the USB Storage device.	

	echo -e "+ Inspecting USB storage device...${WHITE}"

	printf "\n"

	echo -e "+ Checking the folders now exist:"

if [ -d /media/html ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBHTMLLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))

else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "$USBHTMLLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBHTMLLOC does not exist on USB storage device!"

fi	

if [ -d /media/Videos ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBVIDEOSLOC exists."
# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
			
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "$USBVIDEOSLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBVIDEOSLOC does not exist on USB storage device!"

fi

# Check if the Pictures folder exists on the USB Storage device.	
if [ -d /media/Pictures ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBPICTURESLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "$USBPICTURESLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBPICTURESLOC does not exist on USB storage device!"
	
fi

# Check if the Music folder exists on the USB Storage device.	
if [ -d /media/Music ];
then

    echo -e "+${GREEN} [OK]${WHITE} $USBMUSICLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "$USBMUSICLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBMUSICLOC does not exist on USB storage device!"
	
fi


if [ $USBFOLDERMISSING -eq 4 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The required folders exist for the specified USB storage device." >> /home/pi/RPNSMS/eventlog.log

	printf "\n"
	echo -e "+${GREEN} [OK]${WHITE} The USB Storage device contains the required folders."
	
# Start the copy procedure to the Management System:
# Start copying the folder contents to the Management system:

	echo -e "+ Folder transfer status:"
	printf "\n"



# Start the copy procedure to the Management System:
# Pi [1-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [1-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD1:/home/pi/
	VIDEOCOPYSTAT1=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT1 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD1"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD1! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [1-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD1:/home/pi/
	PICTURECOPYSTAT1=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT1 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD1"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD1! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [1-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD1:/home/pi/
	MUSICCOPYSTAT1=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT1 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD1"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD1! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
		
# Start the copy procedure to the Management System:
# Pi [2-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [2-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD2:/home/pi/
	VIDEOCOPYSTAT2=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT2 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD2"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD2! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [2-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD2:/home/pi/
	PICTURECOPYSTAT2=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT2 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD2"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD2! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [2-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD2:/home/pi/
	MUSICCOPYSTAT2=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT2 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD2"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD2! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
		
# Start the copy procedure to the Management System:
# Pi [3-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD3:/home/pi/
	VIDEOCOPYSTAT3=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT3 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD3"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD3! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD3:/home/pi/
	PICTURECOPYSTAT3=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT3 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD3"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD3! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [3-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD3:/home/pi/
	MUSICCOPYSTAT3=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT3 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD3"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD3! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
# Start the copy procedure to the Management System:
# Pi [4-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD4:/home/pi/
	VIDEOCOPYSTAT4=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT4 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD4"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD4! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD4:/home/pi/
	PICTURECOPYSTAT4=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT4 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD4"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD4! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [4-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD4:/home/pi/
	MUSICCOPYSTAT4=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT4 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD4"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD4! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
		
# Start the copy procedure to the Management System:
# Pi [5-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD5:/home/pi/
	VIDEOCOPYSTAT5=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT5 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD5"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD5! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD5:/home/pi/
	PICTURESCOPYSTAT5=$?

# Confirm the Picture folder copied:
if [ $PICTURESCOPYSTAT5 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD5"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD5! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [5-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD5:/home/pi/
	MUSICCOPYSTAT5=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT5 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD5"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD5! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
		
# Start the copy procedure to the Management System:
# Pi [6-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD6:/home/pi/
	VIDEOCOPYSTAT6=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT6 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD6"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD6! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD6:/home/pi/
	PICTURECOPYSTAT6=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT6 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD6"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD6! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [6-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD6:/home/pi/
	MUSICCOPYSTAT6=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT6 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD6"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD6! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
	
# Start the copy procedure to the Management System:
# Pi [7-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD7:/home/pi/
	VIDEOCOPYSTAT7=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT7 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD7"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD7! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD7:/home/pi/
	PICTURECOPYSTAT7=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT7 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD7"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD7! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [7-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD7:/home/pi/
	MUSICCOPYSTAT7=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT7 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD7"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD7! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
# Start the copy procedure to the Management System:
# Pi [8-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD8:/home/pi/
	VIDEOCOPYSTAT8=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT8 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD8"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD8! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD8:/home/pi/
	PICTURECOPYSTAT8=$?

# Confirm the Picture folder copied:
if [ $PICTURECOPYSTAT8 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD8"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD8! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [8-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD8:/home/pi/
	MUSICCOPYSTAT8=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT8 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD8"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD8! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
	
# Start the copy procedure to the Management System:
# Pi [9-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD9:/home/pi/
	VIDEOCOPYSTAT9=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT9 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD9"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD9! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD9:/home/pi/
	PICTURESCOPYSTAT9=$?

# Confirm the Picture folder copied:
if [ $PICTURESCOPYSTAT9 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD9"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD9! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [9-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD9:/home/pi/
	MUSICCOPYSTAT9=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT9 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD9"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD9! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"
	
	
# Start the copy procedure to the Management System:
# Pi [10-10]
# Video files:

	echo -e "+ Copying the Videos folder and its contents... [10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Videos pi@$IPADD10:/home/pi/
	VIDEOCOPYSTAT10=$?

# Confirm the Video folder copied:
if [ $VIDEOCOPYSTAT10 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Videos folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Videos folder to $IPADD10"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Videos folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Videos folder to $IPADD10! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Picture files:

	echo -e "+ Copying the Pictures folder and its contents... [10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Pictures pi@$IPADD10:/home/pi/
	PICTURESCOPYSTAT10=$?

# Confirm the Picture folder copied:
if [ $PICTURESCOPYSTAT10 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Pictures folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Pictures folder to $IPADD10"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Pictures folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Pictures folder to $IPADD10! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

	printf "\n"

# Music files:

	echo -e "+ Copying the Music folder and its contents... [10-10]"
	sshpass -p $PIPASSWORD sudo scp -r -o StrictHostKeyChecking=no -r /media/Music pi@$IPADD10:/home/pi/
	MUSICCOPYSTAT10=$?

# Confirm the Music folder copied:
if [ $MUSICCOPYSTAT10 -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system copied the Music folder." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the Music folder to $IPADD10"
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "The Management system failed to copy the Music folder! (0x00004) (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the Music folder to $IPADD10! Incorrect IP / password or left blank! This will be skipped (0x00004) (0x00010)"
fi

# Check if the user wanted to upload HTML:
# Should the user say yes:
if [ $UPLOADHTMLONLY == 1 ]; then

	echo -e "+ ${GREEN}[OK]${WHITE} Uploading HTML at this time..."

# Copy the HTML files to the apache folder on the Management System:

	echo -e "+ Copying the html folder and its contents..."
	sudo cp -r /media/html/ /var/www/ &> /dev/null
	HTMLCOPYSTAT=$?

# Confirm the HTML folder copied:
if [ $HTMLCOPYSTAT -eq 0 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system copied the html folder from $USBCLONESELECTION." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} The Management system copied the html folder from $USBCLONESELECTION."
	
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD):" "The Management system failed to copy the html folder from $USBCLONESELECTION! (0x00010)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} Failed to copy the html folder from $USBCLONESELECTION! FATAL ERROR! (0x00010)"
fi

	printf "\n"

# Should the user say no:
else

	echo -e "+ ${GREEN}[OK]${WHITE} HTML was not uploaded at this time."

fi


# The file transfer scripted has completed from this stage:

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "+${GREEN} [DONE]${WHITE} The USB Storage Media has transferred to the Management system."
	echo -e "+${WHITE} Confirm the 'folder transfer status' passed with ${GREEN}[OK]${WHITE}. Deploy the Media"
	echo -e "+${WHITE} files through the Management system, using either: 'Single Change mode'"
	echo -e "+${WHITE} or 'Perform Mass change' and selecting: 'Copy USB upload'."
	echo -e "+---------------------------------------------------------------------------+"

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $USBCLONESELECTION..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

	read -p "! Press any key to return to the main menu..."
	exec "$RPNAUTOEXECSCRIPT"
	
fi


# If there's a problem with mounting the USB:
else

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "There was a problem creating the folders on the USB Storage device! (0x00010)" >> /home/pi/RPNSMS/eventlog.log


fi
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to Mount: $USBCLONESELECTION! (0x00008)"

# Unmount the disk to prevent issues:	
	echo -e "+ Attempting to eject $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi
fi

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Attempting to eject $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

	printf "\n"

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(MANAGEMENT-SYSTEM-USB-MEDIA-UPLOAD-MASS):" "There was a problem creating the folders on the USB Storage device! (0x00010)" >> /home/pi/RPNSMS/eventlog.log

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "!${RED}[FAIL]${WHITE} There was a problem copying media files from the USB Storage device!"
	echo -e "! Ensure files were copied to the USB Storage device.(0x00010)"
	echo -e "!${WHITE} Use the advanced options menu and select 'Setup USB Media Uploader'"
	echo -e "! to reconfigure the USB Storage device and try again."
	echo -e "+---------------------------------------------------------------------------+"
	read -p "! Press any key to return to the main menu..."
	clear
	exec "$RPNAUTOEXECSCRIPT"

		;;

        *) echo "invalid option $REPLY";;
    esac
done
fi
fi
