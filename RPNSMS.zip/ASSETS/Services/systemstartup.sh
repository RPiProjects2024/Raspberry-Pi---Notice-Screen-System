#!/bin/bash
# Raspberry Pi Management system - Initialisation script.
# use this after edits to COMPILE Properly: sed -i -e 's/\r$//' systemstartup.bash
# ------------------------------------------------------------------------------------------------
# This script and its code have been designed to function as part of the notice screen system. 
# Modifying or changing the code and or files stored could cause problems. 
# If you wish to make changes, do so at your own risk.
# ------------------------------------------------------------------------------------------------
# This script ensures the Management System initialisation script only runs once on a full system
# start up process.

# Where the initialisation pass file is stored.
InitialisationPass="/home/pi/RPNSMS/ASSETS/Services/initpassed.INIT"

sudo rm $InitialisationPass &> /dev/null

