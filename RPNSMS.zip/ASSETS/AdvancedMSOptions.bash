#!/bin/bash
# Raspberry Pi Notice Screen Management system scripts.
# Version 1.0 - Created by Nick B, 2022.
# Use this after edits to COMPILE Properly: sed -i -e 's/\r$//' autoexec.bash

# ------------------------------------------------------------------------------------------------
# This script and its code have been designed to function as part of the notice screen system. 
# Modifying or changing the code and or files stored could cause problems. 
# If you wish to make changes, do so at your own risk.
# ------------------------------------------------------------------------------------------------

#Global variables:
	VERSION="1.0"  																  # Version number. Used in echo strings.
	RPNSCRIPT="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash"				  # Location of the single pi script.
	RPNMASSSCRIPT="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash"  # Location of the MASS pi script.
	RPNAUTOEXECSCRIPT="/home/pi/RPNSMS/autoexec.bash"							  # Location of the autoexec script.
	CMDACTIONS="-y" 															  # Default CMD line action for automation.
	InitialisationPass="/home/pi/RPNSMS/ASSETS/Services/initpassed.INIT" 		  # Check if the Management system already performed a check.
	CURRENTHOSTIP=$(hostname -I)												  # Management system IP address.
	PITEMP=$(sudo vcgencmd measure_temp)										  # Get the CPU Temperature after login
    PIHOSTNAME=$(sudo hostname) &> /dev/null									  # Obtain the Hostname.
	CURRENTUSER=$(whoami)														  # Obtain the current user.
	PASSWORDCHECKLOOP="1" 															# Ensures the passwords for accessing Pi devices match.

	NETWORKINTERFACEUPDATED="1" 				# Value is changed to 0 when scripts are correct.
	HOSTUPDATED="1" 							# Value is changed to 0 when scripts are correct.
	HOSTSFILE="/etc/hosts"					# Location of the host file. DO NOT CHANGE.
	HOSTNAMEFILE="/etc/hostname"			# Location of the host file. DO NOT CHANGE.
	HOSTFILELINE="raspberrypi"			  	# Default Raspberry Pi name. DO NOT CHANGE.
	NETWORKFILE="/etc/dhcpcd.conf" 			# Location of the network file. DO NOT CHANGE.
	IPV4INPUTCHECK="1"						# Used to ensure the IPV4 field is not left blank.
	DNSINPUTCHECK="1"						# Used to ensure the DNS field is not left blank.
	GATEWAYINPUTCHECK="1"					# Used to ensure the GATEWAY field is not left blank.
	HOSTNAMEINPUTCHECK="1"					# Used to ensure the HOSTNAME field is not left blank.	
	IPV4LINE="0.0.0.1"						# Contains value of IPV4 line in interface file. DO NOT CHANGE.
	DNSLINE="0.0.0.2"						# Contains value of Netmask line in interface file. DO NOT CHANGE.
	GATEWAYLINE="0.0.0.3"					# Contains value of Gateway line in interface file. DO NOT CHANGE

# Repair Script file locations:
	autostartbak="/home/pi/RPNSMS/ASSETS/autostartbak/autostart" 						# Check the file exists.
	Music="/home/pi/RPNSMS/ASSETS/Music/display.desktop"                                # Check the file exists.
	Picturesbak="/home/pi/RPNSMS/ASSETS/Pictures/bak/autostart" 						# Check the file exists.
	Pictures="/home/pi/RPNSMS/ASSETS/Pictures/autostart" 								# Check the file exists.
	Video="/home/pi/RPNSMS/ASSETS/Video/display.desktop" 								# Check the file exists.
	autostart="/home/pi/RPNSMS/ASSETS/autostart" 										# Check the file exists.
	NoticeScreenMS="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash" 					# Check the file exists.
	NoticeScreenMSMASS="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash" 	# Check the file exists.
	EVENTLOGFILELOC="/home/pi/RPNSMS/eventlog.log"										# Eventlog location.

# Notice Screen Management System IMG variables:
	CURRENTDATE=$(date +"%m-%d-%Y")						# The current date for creating backup IMG files.
	CURRENTTIME=$(date +%T)								# The current time for creating backup IMG files.
	DISKCHOICESELECTION="1"								# Used to close disk selection loop.


# Commandline colors:
	RED='\033[1;31m'
	WHITE='\033[1;37m'
	GREEN='\033[1;32m'

# Management System Parameters:
	PIUSER="pi" # Username for accessing Raspberry Pi devices. Default is pi.

# Event log:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "User: $CURRENTUSER has logged into the Management system." >> /home/pi/RPNSMS/eventlog.log

# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log
	
# Clear the screen
	clear
# UI
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager - Advanced options. ${GREEN}Version: $VERSION ${WHITE}" 
	echo -e "${WHITE}+---------------------------------------------------------------------------+" 
	echo -e "${GREEN}IP Address:${WHITE} $CURRENTHOSTIP"
	echo -e "${GREEN}Hostname:${WHITE} $PIHOSTNAME"	
	echo -e "${GREEN}Please choose an advanced option:${WHITE}                                   [CPU $PITEMP]" # <Padding to make this appear on the right side of the screen.
	echo -e "${WHITE}+---------------------------------------------------------------------------+"

# List values:	
	options=("Export event logs" "Change IP address" "Change hostname" "Create backup IMG" "Setup USB Media Uploader" "Reboot Management System" "Shutdown Management System" "Return to menu")
select opt in "${options[@]}"
do
    case $opt in

# Export Event logs:
        "Export event logs")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-ADV):" "Loaded 'Export event logs'." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+---------------------------------------------------------------------------+"
	echo -e  "Export Event Log file:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "Use this to export the current event log file to an external USB Storage device."	
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ ${GREEN}Please connect a USB storage device to the Management System...${WHITE}"
	read -p "! Press any key when ready..."

	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s


while [ $DISKCHOICESELECTION -gt 0 ]; do
# Show connected devices:
	echo "+---------------------------------------------------------------------------+"
	lsblk	
	echo "+---------------------------------------------------------------------------+"
	echo -e "Type the NAME of the device you wish to copy the eventlog to."
	echo -e "${GREEN}To refresh, leave blank and press ENTER.${WHITE}"
	echo -e "${GREEN}NAME Example: ${WHITE}sda1${WHITE}"
	echo -e "Type EXIT to return to the main menu."
	read SDACLONE

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $SDACLONE == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $SDACLONE == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

if [ -z "$SDACLONE" ]
then
# Clear the screen to avoid confusion with the previous lsblk command.
	clear
	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s
else
	DISKCHOICESELECTION="0"
fi
done

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
	echo -e "${RED}Please confirm the following details:${WHITE}"
	echo -e "+ Device NAME to copy the event log to: $SDACLONE"
	echo -e "+ Save path: $SDACLONE/""eventlog ""$CURRENTDATE".log
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac


# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	sudo mount /dev/$SDACLONE /media &> /dev/null
	USBMOUNTOP=$?

if [ $USBMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Mounted: $SDACLONE successfully."

# Copy the current log folder:
	sudo cp /home/pi/RPNSMS/eventlog.log /media/

# Rename the copied log file:
	sudo mv /media/eventlog.log /media/"eventlog ""$CURRENTDATE".log # &> /dev/null
	EVENTCOPYJOB=$?

if [ $EVENTCOPYJOB -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-IMG):" "The event log was exported successfully." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The event log was exported successfully."
	sleep 2s
# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $SDACLONE..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $SDACLONE successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $SDACLONE! (0x00008)"
fi

	read -p "Press any key to return to the main menu..."
	exec "$RPNAUTOEXECSCRIPT"

else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-IMG):" "The event log failed to export to the USB storage device! (0x00008)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} The event log failed to export to the USB storage device! (0x00008)"

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $SDACLONE..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $SDACLONE successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $SDACLONE! (0x00008)"
fi

fi
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to Mount: $SDACLONE! (0x00008)"
fi

	read -p "Press any key to return to the main menu..."
	clear
	exec "$RPNAUTOEXECSCRIPT"


else
	exec "$RPNAUTOEXECSCRIPT"
fi
            ;;
			
# Change IP Address:
        "Change IP address")
# Event log entry:

	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-ADV):" "Loaded 'Change IP address'." >> /home/pi/RPNSMS/eventlog.log 
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Change IP Address${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo -e "Use this option to change the IP address and other network configurations."
	echo -e "This will update the below network configurations for eth0 (Ethernet Only):"	
	echo -e "${GREEN}+ IPV4 Address${WHITE}"
	echo -e "${GREEN}+ Subnet mask${WHITE}"
	echo -e "${GREEN}+ Gateway${WHITE}"
	echo -e "${RED}! WARNING:"
	echo -e "! Notice screens using HTML addresses from the Management system will"
	echo -e "! require the IP address to be updated on each Notice screen.${WHITE}"
	echo -e "! Update any applications used to the new IP address, for remote access.${WHITE}"
	echo -e "${RED}! Ensure the updated IP address is not already broadcasting!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# NETWORK ADDRESS UPDATE SECTION:

while [ $NETWORKINTERFACEUPDATED -gt 0 ]; do
	printf "\n"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "Network Configuration setup"
	echo -e "${GREEN}Current eth0 IPV4 Address:${WHITE} $CURRENTHOSTIP"	
    echo -e "+---------------------------------------------------------------------------+"
	
while [ $IPV4INPUTCHECK -gt 0 ]; do
# Type the IPV4 address.
	printf "\nPlease type an IPV4 address. Use the following format: 0.0.0.0\n"
	read IPV4

if [ -z "$IPV4" ]
then
      echo -e "${RED}[ERROR]${WHITE} The IP Address was left blank!"
else
IPV4INPUTCHECK="0"
fi
done

# Type the IPV4 address again.
	printf "\nPlease type the same IPV4 address again. Use the following format: 0.0.0.0\n"
	read IPV4CHECK

# IF Statement to check if the two fields match.
	if [ $IPV4 == $IPV4CHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} IPV4 matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} IPV4 did not match."
	fi

while [ $DNSINPUTCHECK -gt 0 ]; do
# Type the Netmask.
	printf "\nPlease type the Subnet mask. Use the following format: 0.0.0.0\n"
	read DNS

if [ -z "$DNS" ]
then
      echo -e "${RED}[ERROR]${WHITE} The Subnet mask was left blank!"
else
DNSINPUTCHECK="0"
fi
done

# Type the Netmask again.
	printf "\nPlease type the same Subnet mask again. Use the following format: 0.0.0.0\n"
	read DNSCHECK

# IF Statement to check if the two fields match.
if [ $DNS == $DNSCHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} Subnet mask matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} Subnet mask did not match."
fi

while [ $GATEWAYINPUTCHECK -gt 0 ]; do
# Type the default Gateway.
	printf "\nPlease type the default Gateway. Use the following format: 0.0.0.0\n"
	read GATEWAY

if [ -z "$GATEWAY" ]
then
      echo -e "${RED}[ERROR]${WHITE} The GATEWAY was left blank!"
else
GATEWAYINPUTCHECK="0"
fi
done

# Type the default Gateway again.
	printf "\nPlease type the same default Gateway again. Use the following format: 0.0.0.0\n"
	read GATEWAYCHECK

# IF Statement to check if the two fields match.
if [ $GATEWAY == $GATEWAYCHECK ]; then
	((NETWORKCOUNT=NETWORKCOUNT+1))
	echo -e "+${GREEN} [OK]${WHITE} Gateway matched."
	else
	echo -e "!${RED} [FAIL]${WHITE} Gateway did not match."
fi

# Make sure that all 3 fields matched. 
# Then, set NETWORKCOUNT to zero to end while loop.
if [ $NETWORKCOUNT == 3 ]; then
	NETWORKINTERFACEUPDATED="0"

# Apply permissions to network folder. Required to copy the preconfigured file.
#	sudo chmod 777 -R /etc/network/
	sudo chown pi /etc/dhcpcd.conf

#Copy preconfigured interfaces file.
	sudo cp dhcpcd.conf /etc/

# From this section, we now update the IP configuration.
# A full restart is required for the changes to apply.

# Now update the network configuration.
	echo "+ Updating network configuration..."

# IPV4 Address copy operation: 
	sudo sed -i "s/$IPV4LINE/$IPV4/g" "$NETWORKFILE"

# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy IPV4 line."

# Domain Name copy operation.: 
	sudo sed -i "s/$DNSLINE/$DNS/g" "$NETWORKFILE"
# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy Subnet mask line."	

# Netmask Address copy operation.: 
	sudo sed -i "s/$GATEWAYLINE/$GATEWAY/g" "$NETWORKFILE"
# Display message one command above has completed.
	echo -e "+${GREEN} [OK]${WHITE} Attempted to copy Gateway line."

	echo    "+---------------------------------------------------------------------------+"
    echo -e "+${GREEN} [OK]${WHITE} Network interfaces updated."
	echo    "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Updated IPV4 Address: ${WHITE}$IPV4"
	echo -e "${GREEN}Updated Subnet mask: ${WHITE}$DNS"	
	echo -e "${GREEN}Updated Default Gateway: ${WHITE}$GATEWAY"
	read -p "Press any key to reboot the Raspberry Pi."	
	echo -e "${RED}! Rebooting in 5 seconds...${WHITE}"
	sleep 5s
	sudo shutdown -r now
else
	echo -e "!${RED} [FAIL]${WHITE} One or more fields did not match."
# Reset NETWORKCOUNT or it could cause problems.
	NETWORKCOUNT="0"
fi
done

# Should the user type no, exit to the autoexec menu.
else
	exec "$RPNAUTOEXECSCRIPT"
fi

 ;;
			
# Change Hostname:
        "Change hostname")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-ADV):" "Loaded 'Change hostname'." >> /home/pi/RPNSMS/eventlog.log

# Update the Raspberry Pi Management System.

	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Change hostname:${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	echo -e "Use this option to change the hostname of this Management system."	
	echo -e "${RED}! WARNING:"
	echo -e "! Notice screens using the internal hostname for HTMLS from the"
	echo -e "! Management system will require the hostname to be updated"
	echo -e "! on each Notice screen ${WHITE}(example: http://noticesms-01/index.html).${WHITE}"
	echo -e "${RED}! Ensure the updated hostname is not already in use!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

while [ $HOSTUPDATED -gt 0 ]; do
# Configure host name
    echo "+---------------------------------------------------------------------------+"
	echo -e "Please type a suitable Hostname for this Raspberry Pi."
	echo -e "Example: NOTICESMS-01. Use ASCII characters only.${WHITE}"
	echo -e "${RED}Current hostname: $PIHOSTNAME${WHITE}"
    echo "+---------------------------------------------------------------------------+"
while [ $HOSTNAMEINPUTCHECK -gt 0 ]; do
	read HOSTNAMEUPDATE

if [ -z "$HOSTNAMEUPDATE" ]
then
      echo -e "${RED}[ERROR]${WHITE} The Hostname was left blank!"
      echo -e "Please type a suitable Hostname for this Notice system."	  	  
else
HOSTNAMEINPUTCHECK="0"
fi
done

	echo "Typed Hostname: '$HOSTNAMEUPDATE'."
	echo "Please type the hostname once more."
	read HOSTNAMECHECK

# Update the Hostname now. Check that both names match.
	if [ $HOSTNAMEUPDATE == $HOSTNAMECHECK ]; then

# The host name matched, update the host name.
# Update the hostname through raspi-config:
	sudo raspi-config nonint do_hostname $HOSTNAMEUPDATE

# Domain Name copy operation.: 
	sudo sed -i "s/$HOSTFILELINE/$HOSTNAMEUPDATE/g" "$HOSTSFILE"
	sudo sed -i "s/$HOSTFILELINE/$HOSTNAMEUPDATE/g" "$HOSTNAMEFILE"
	
# Change the hostname now to allow tightvnc to configure correctly.
	sudo hostnamectl set-hostname $HOSTNAMEUPDATE

# Restart mDNS daemon service:
	sudo systemctl restart avahi-daemon
	HOSTUPDATED="0"		
# Output after updating hostname.
    echo "+---------------------------------------------------------------------------+"
    echo -e "+${GREEN} [OK]${WHITE} The Hostname has been updated."
	echo -e "${GREEN}  Updated hostname: ${WHITE}$HOSTNAMEUPDATE"
    echo "+---------------------------------------------------------------------------+"
	read -p "Press any key to reboot the Raspberry Pi."	
	echo -e "${RED}! Rebooting in 5 seconds...${WHITE}"
	sleep 5s
	sudo shutdown -r now	
	else
# The host name did not match. Restart while loop.
	echo -e "!${RED} [FAIL]${WHITE} The host names did not match."
	fi
# Closes the while loop.
done

# Should the user type no, exit to the autoexec menu.
else
	exec "$RPNAUTOEXECSCRIPT"
	fi

            ;;
			
# Reboot Management System:
        "Reboot Management System")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-ADV):" "Loaded 'Reboot Management System'." >> /home/pi/RPNSMS/eventlog.log

	echo "+---------------------------------------------------------------------------+"
	echo "Reboot Management System:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "+${RED} Are you sure you want to reboot this Management system?${WHITE}"
	echo -e "+${RED} IP Address:${WHITE} $CURRENTHOSTIP"												  										  
    echo -e "+${RED} Hostname:${WHITE} $PIHOSTNAME"
	
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo "+ Rebooting Management system..."
	sudo shutdown -r now

else
	exec "$RPNAUTOEXECSCRIPT"
fi

            ;;
			
# Shutdown Management System:
        "Shutdown Management System")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-ADV):" "Loaded 'Shutdown Management System'." >> /home/pi/RPNSMS/eventlog.log
	
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Shutdown Management System${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "+${RED} Are you sure you want to shutdown this Management system?${WHITE}"
	echo -e "+${RED} IP Address:${WHITE} $CURRENTHOSTIP"												  										  
    echo -e "+${RED} Hostname:${WHITE} $PIHOSTNAME"									 
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Shutdown the Notice screen: 
	echo "+ Shutting down Management system..."
	sudo shutdown -h now
else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
            ;;

        "Create backup IMG")

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Create backup IMG of this Management System${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}You can create a full IMG backup of this Management system,${WHITE}"
	echo -e "${GREEN}in the event of a disaster recovery situation. The restored IMG${WHITE}"
	echo -e "${GREEN}can be flashed to another SD card and redeployed."
	echo -e "${RED}It is advised to only create an IMG backup if this system is in a full"
	echo -e "${RED}working state. You will also require a USB PEN drive with sufficient"
	echo -e "${RED}space to copy the IMG file to. Ensure no important data is stored on"
	echo -e "${RED}the USB storage device!${WHITE}"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ ${GREEN}Please connect a USB storage device to the Management System...${WHITE}"
	read -p "! Press any key when ready..."

	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s


while [ $DISKCHOICESELECTION -gt 0 ]; do
# Show connected devices:
	echo "+---------------------------------------------------------------------------+"
	lsblk	
	echo "+---------------------------------------------------------------------------+"
	echo -e "Type the NAME of the device you wish to copy the IMG to."
	echo -e "${GREEN}To refresh, leave blank and press ENTER.${WHITE}"
	echo -e "${GREEN}NAME Example: ${WHITE}sda1${WHITE}"
	echo -e "Type EXIT to return to the main menu."
	read SDACLONE

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $SDACLONE == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $SDACLONE == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

if [ -z "$SDACLONE" ]
then
# Clear the screen to avoid confusion with the previous lsblk command.
	clear
	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s
else
	DISKCHOICESELECTION="0"
fi
done

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Confirm backup IMG parameters!${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Please confirm the following details:${WHITE}"
	echo -e "+ Device NAME to copy the IMG to: $SDACLONE"
	echo -e "+ Save path: $SDACLONE/""NSMS IMAGE BACKUP ""$CURRENTDATE".IMG
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	sudo mount /dev/$SDACLONE /media &> /dev/null
	USBMOUNTOP=$?

if [ $USBMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Mounted: $SDACLONE successfully."

	printf "\n"

	echo -e "+ Starting IMG creation.${RED} DO NOT TURN OFF OR REMOVE THE USB STORAGE DEVICE...${WHITE}"

	sudo dd if=/dev/mmcblk0 of=/media/"NSMS IMAGE BACKUP ""$CURRENTDATE".IMG status=progress 
	IMGCREATIONJOB=$?

if [ $IMGCREATIONJOB -eq 0 ]; then
# Event log entry:
	printf "\n"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-IMG):" "A backup IMG of this Management system created successfully." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "+${GREEN} [OK]${WHITE} The backup IMG of this Management system created successfully."
	echo -e "+---------------------------------------------------------------------------+"
# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $SDACLONE..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $SDACLONE successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $SDACLONE! (0x00008)"
fi

	read -p "Press any key to return to the main menu..."
	printf "\n"
	exec "$RPNAUTOEXECSCRIPT"

else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-IMG):" "The backup IMG creation of this Management system failed or was aborted! (0x00008)" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "!${RED} [FAIL]${WHITE} The backup IMG failed to be created or was aborted! (0x00008)"
	echo -e "+---------------------------------------------------------------------------+"
	
# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $SDACLONE..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $SDACLONE successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $SDACLONE! (0x00008)"
fi

fi
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to Mount: $SDACLONE! (0x00008)"
fi

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $SDACLONE..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $SDACLONE successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $SDACLONE! (0x00008)"
fi

	printf "\n"
	read -p "! Press any key to return to the main menu..."
	exec "$RPNAUTOEXECSCRIPT"
	
else
	exec "$RPNAUTOEXECSCRIPT"
fi

            ;;

        "Setup USB Media Uploader")

	echo "+---------------------------------------------------------------------------+"
	echo "Setup USB Media Storage device:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${WHITE}Use this to create designated folders on a USB Storage device"
	echo -e "which can be used to upload content to Notice Screens."
	echo -e "${WHITE}Supported file systems: EXFAT (More to be tested)"
	echo -e "${RED}This will not format the USB storage device, however please ensure"
	echo -e "${RED}any important files are backed up, before proceeding.${WHITE}"
	echo -e "${WHITE}It is recommended to use a dedicated USB Storage device."
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	echo -e "+ ${GREEN}Please connect a USB storage device to the Management System...${WHITE}"
	read -p "! Press any key when ready..."

	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s


while [ $DISKCHOICESELECTION -gt 0 ]; do
# Show connected devices:
	echo "+---------------------------------------------------------------------------+"
	lsblk	
	echo "+---------------------------------------------------------------------------+"
	echo -e "Type the NAME of the device you wish to setup as a USB Media device."
	echo -e "${GREEN}To refresh, leave blank and press ENTER.${WHITE}"
	echo -e "${GREEN}NAME Example: ${WHITE}sda1${WHITE}"
	echo -e "Type EXIT to return to the main menu."
	read USBCLONESELECTION

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $USBCLONESELECTION == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
	echo "Exit Command not defined. Running script." &> /dev/null
fi

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $USBCLONESELECTION == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else
echo "Exit Command not defined. Running script." &> /dev/null
fi

if [ -z "$USBCLONESELECTION" ]
then
# Clear the screen to avoid confusion with the previous lsblk command.
	clear
	echo -e "+ Allowing for connected devices to appear..."	
	sleep 4s
else
	DISKCHOICESELECTION="0"
fi
done

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Confirm USB Media Storage device parameters!${WHITE}:"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "${RED}Please confirm the following details:${WHITE}"
	echo -e "+ Device NAME to create required folders: $USBCLONESELECTION"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";
esac

	printf "\n"

# Check if the user said yes or no.
if [ $YNOPTION -eq 1 ]; then

	sudo mount /dev/$USBCLONESELECTION /media &> /dev/null
	USBMOUNTOP=$?

if [ $USBMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Mounted: $USBCLONESELECTION successfully."

	printf "\n"

	echo -e "+ Configuring the USB device to be used as a Media storage uploader...${WHITE}"

	# Define folder locations (event logging):
	USBHTMLLOC="/media/html"
	USBVIDEOSLOC="/media/Videos"
	USBPICTURESLOC="/media/Pictures"
	USBMUSICLOC="/media/Music"
	USBFOLDERMISSING="0" # An initial value is given to prevent an empty var, should folders already exists on the USB device.

# Make html folder:
	# Create folder on USB:
	sudo mkdir /media/html &> /dev/null
	
	# Set Pi as owner:
	sudo chown pi /media/html &> /dev/null

	# Display message:
	echo -e "+${GREEN} [OK]${WHITE} Attempted to create the html folder on $USBCLONESELECTION" 
	
# Make Videos folder
	# Create folder on USB:
	sudo mkdir /media/Videos &> /dev/null
	
	# Set Pi as owner:
	sudo chown pi /media/Videos &> /dev/null

	# Display message:
	echo -e "+${GREEN} [OK]${WHITE} Attempted to create the Videos folder on $USBCLONESELECTION" 

	
# Make Pictures folder:

	# Create folder on USB:
	sudo mkdir /media/Pictures &> /dev/null
	
	# Set Pi as owner:
	sudo chown pi /media/Pictures &> /dev/null

	# Display message:
	echo -e "+${GREEN} [OK]${WHITE} Attempted to create the Pictures folder on $USBCLONESELECTION" 

# Make Music folder:

	# Create folder on USB:
	sudo mkdir /media/Music &> /dev/null
	
	# Set Pi as owner:
	sudo chown pi /media/Music &> /dev/null

	# Display message:
	echo -e "+${GREEN} [OK]${WHITE} Attempted to create the Music folder on $USBCLONESELECTION" 


	printf "\n"

# Confirm the directories were created successfully:	
# Check if the HTML folder exists on the USB Storage device.	

	echo -e "+ Checking the folders now exist:"

if [ -d /media/html ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBHTMLLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))

else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBHTMLLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBHTMLLOC does not exist on USB storage device!"

fi	

if [ -d /media/Videos ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBVIDEOSLOC exists."
# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
			
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBVIDEOSLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBVIDEOSLOC does not exist on USB storage device!"

fi

# Check if the Pictures folder exists on the USB Storage device.	
if [ -d /media/Pictures ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBPICTURESLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBPICTURESLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBPICTURESLOC does not exist on USB storage device!"
	
fi

# Check if the Music folder exists on the USB Storage device.	
if [ -d /media/Music ];
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $USBMUSICLOC exists."

# Add value to variable, used to ensure the folder creation completed for all folders:	
	((USBFOLDERMISSING=USBFOLDERMISSING+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOAD):" "$USBMUSICLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "!${RED} [WARN]${WHITE} $USBMUSICLOC does not exist on USB storage device!"
	
fi


if [ $USBFOLDERMISSING -eq 4 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-Upload):" "A USB Media Storage Uploader was configured successfully." >> /home/pi/RPNSMS/eventlog.log

	printf "\n"
	echo -e "+---------------------------------------------------------------------------+"
	echo -e "+${GREEN} [OK]${WHITE} The USB Storage device has been configured."
	echo -e "+${WHITE} You can now connect this USB stick to a computer and drag files "
	echo -e "+${WHITE} into the appropriate folder on the USB Storage device. Then use either"
	echo -e "+${WHITE} single mode or mass mode to upload the media to Notice screens."
	echo -e "+---------------------------------------------------------------------------+"
	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $USBCLONESELECTION..."
	sudo umount /media &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

	read -p "Press any key to return to the main menu..."
	printf "\n"
	exec "$RPNAUTOEXECSCRIPT"

# If there's a problem with folder creation:
else
	printf "\n"

	echo -e "+---------------------------------------------------------------------------+"
	echo -e "! ${RED}[FAIL]${WHITE} There was a problem creating the folders on the USB Storage device!"
	echo -e "! FATAL error! (0x00010)"
	echo -e "+---------------------------------------------------------------------------+"


# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-USB-UPLOADER):" "There was a problem creating the folders on the USB Storage device! (0x00010)" >> /home/pi/RPNSMS/eventlog.log

# Unmount the disk to prevent issues:	
	echo -e "+ Ejecting $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi

fi
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to Mount: $USBCLONESELECTION! (0x00008)"

	printf "\n"

# Unmount the disk to prevent issues:	
	echo -e "+ Attempting to eject $USBCLONESELECTION..."
	sudo umount /media  &> /dev/null
	USBUMOUNTOP=$?

# Confirm the disk was ejected?
if [ $USBUMOUNTOP -eq 0 ]; then
	echo -e "+${GREEN} [OK]${WHITE} Ejected: $USBCLONESELECTION successfully."
	echo -e "${GREEN}+ [USB]${WHITE} You can now remove the USB Storage device from the Management System."
else
	echo -e "!${RED} [FAIL]${WHITE} Failed to eject: $USBCLONESELECTION! (0x00008)"
fi
fi

	read -p "Press any key to return to the main menu..."
	clear
	exec "$RPNAUTOEXECSCRIPT"

else
	exec "$RPNAUTOEXECSCRIPT"
fi
	

			;;	
			
			"Return to menu")
		
	exec "$RPNAUTOEXECSCRIPT"
			
esac
done
