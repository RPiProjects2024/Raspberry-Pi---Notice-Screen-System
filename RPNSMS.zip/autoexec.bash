#!/bin/bash
# Raspberry Pi Notice Screen Management system scripts.
# Version 1.0 - Created by Nick B, 2022.
# Use this after edits to COMPILE Properly: sed -i -e 's/\r$//' autoexec.bash

# ------------------------------------------------------------------------------------------------
# This script and its code have been designed to function as part of the notice screen system. 
# Modifying or changing the code and or files stored could cause problems. 
# If you wish to make changes, do so at your own risk.
# ------------------------------------------------------------------------------------------------

#Global variables:
	VERSION="1.0"  																  # Version number. Used in echo strings.
	RPNSCRIPT="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash"				  # Location of the single pi script.
	RPNMASSSCRIPT="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash"  # Location of the MASS pi script.
	RPNAUTOEXECSCRIPT="/home/pi/RPNSMS/autoexec.bash"							  # Location of the autoexec script.
	CMDACTIONS="-y" 															  # Default CMD line action for automation.
	InitialisationPass="/home/pi/RPNSMS/ASSETS/Services/initpassed.INIT" 		  # Check if the Management system already performed a check.
	CURRENTHOSTIP=$(hostname -I)												  # Management system IP address.
	PITEMP=$(sudo vcgencmd measure_temp)										  # Get the CPU Temperature after login
    PIHOSTNAME=$(sudo hostname) &> /dev/null									  # Obtain the Hostname.
	CURRENTUSER=$(whoami)														  # Obtain the current user.
	PASSWORDCHECKLOOP="1" 														  # Ensures the passwords for accessing Pi devices match.
	EVENTLOGFILELOC="/home/pi/RPNSMS/eventlog.log"								  # Location of the eventlog file.	
	NoticeScreenADV="/home/pi/RPNSMS/ASSETS/AdvancedMSOptions.bash"				  # Location of the Advanced MS Options file.

# Management System Repair Initialization variables:
	logfile="/home/pi/RPNSMS/eventlog.log" 						                        # Check the file exists.
	autostartbak="/home/pi/RPNSMS/ASSETS/autostartbak/autostart" 						# Check the file exists.
	Music="/home/pi/RPNSMS/ASSETS/Music/display.desktop"                                # Check the file exists.
	Picturesbak="/home/pi/RPNSMS/ASSETS/Pictures/bak/autostart" 						# Check the file exists.
	Pictures="/home/pi/RPNSMS/ASSETS/Pictures/autostart" 								# Check the file exists.
	Video="/home/pi/RPNSMS/ASSETS/Video/display.desktop" 								# Check the file exists.
	autostart="/home/pi/RPNSMS/ASSETS/autostart" 										# Check the file exists.
	NoticeScreenMS="/home/pi/RPNSMS/NoticeScreenManagementSystem.bash" 					# Check the file exists.
	NoticeScreenMSMASS="/home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash" 	# Check the file exists.
	AutoexecLOC="/home/pi/RPNSMS/autoexec.bash"											# Check the file exists.
	AdvancedMSOptions="/home/pi/RPNSMS/ASSETS/AdvancedMSOptions.bash"					# Check the file exists.
	AutoUpdate="/home/pi/RPNSMS/AutoUpdate.sh"											# Check the file exists.
	ApacheVersion=$(apache2 -v)															# Apache Version and Build.

# Notice Screen Management System IMG variables:
	CURRENTDATE=$(date +"%m-%d-%Y")						# The current date for creating backup IMG files.
	CURRENTTIME=$(date +%H:%M:%S)						# The current time for creating backup IMG files.
	DISKCHOICESELECTION="1"								# Used to close disk selection loop.

# Notice Screen Management System Update URL (GIT Hub):
	MSUPDATE="0"			# States if the user wishes to perform the Management System update.
	MSUPDATEURL="https://github.com/RPiProjects2024/RPi-Notice-Screen-System.git" 		# github URL
	MSUPDATELOC="/home/pi/RPNSMS/TEMPUPDATE"											# Where Update is downloaded to.

# Commandline colors:
	RED='\033[1;31m'
	WHITE='\033[1;37m'
	GREEN='\033[1;32m'

# Management System Parameters:
	PIUSER="pi" # Username for accessing Raspberry Pi devices. Default is pi.

# Event log:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "User: $CURRENTUSER has logged into the Management system." >> /home/pi/RPNSMS/eventlog.log

# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log
	
# Clear the screen
	clear
# UI
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Raspberry Pi Notice Screen Manager. ${GREEN}Version: $VERSION ${WHITE}" 
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
# Check that the log file exists. This could be very suspicious if it's missing. 
if [ -f "$InitialisationPass" ]; then   
	echo -e "${GREEN}Management system READY.${WHITE}"
	else  
	echo -e "${RED}WARNING: Management system initialization failed! Check the log file!"  
fi  
	echo -e "${WHITE}The Management system has been${GREEN} $(uptime -p)${WHITE}."
	echo -e "${GREEN}IP Address:${WHITE} $CURRENTHOSTIP"
	echo -e "${GREEN}Hostname:${WHITE} $PIHOSTNAME"	
	echo -e "${GREEN}Please choose an option:${WHITE}                                   [CPU $PITEMP]" # <Padding to make this appear on the right side of the screen.
	echo -e "${WHITE}+---------------------------------------------------------------------------+"

# List values:	
	options=("Single change mode" "Perform mass change" "Remove known SSH hosts" "Check for Updates" "Repair Management System" "View event logs" "Advanced options")
select opt in "${options[@]}"
do
    case $opt in

# Load the Management system for a single Pi change.
        "Single change mode")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Loaded 'Single change mode'." >> /home/pi/RPNSMS/eventlog.log
	exec "$RPNSCRIPT"
            ;;

# Load the Management system for a mass change.
        "Perform mass change")
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Loaded 'Perform mass change'." >> /home/pi/RPNSMS/eventlog.log
	exec "$RPNMASSSCRIPT"			
            ;;

# Clear a known host from SSH (When building a new Pi with different SSH Keygens)
        "Remove known SSH hosts")

# Warn the user about the process.
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "${RED}Remove known SSH hosts:${WHITE}"
	echo -e "DANGER!${WHITE} Removing a known SSH key can be ${RED}very dangerous!"
	echo -e "${WHITE}This should ONLY be done when an existing Raspberry Pi "
	echo -e "is re-built and the remote identification has changed."
	echo -e "Otherwise, ${RED}please type exit to return to the main menu${WHITE}."
	echo -e "Never remove a working Raspberry Pi from the known hosts unless"
	echo -e "you know the device has just been rebuilt and configured by a" 
	echo -e "network administrator! Otherwise, someone could try pretending"
	echo -e "be a host but be an attacker ${RED}(man-in-the-middle attack)!"

# The user must type the address of the Raspberry Pi they wish to remove from the known SSH hosts file.
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "Known SSH remover:"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	echo -e "${GREEN}Please type the IP Address of the Raspberry Pi:${WHITE}"
	echo -e "${GREEN}Type EXIT to return to the main menu.${WHITE}"
	echo -e "${WHITE}+---------------------------------------------------------------------------+"
	read IPADDRESS
	printf "\n"

# If the user types EXIT, return to AUTOEXEC script (CAPS).
if [ $IPADDRESS == EXIT ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else

# If the user types EXIT, return to AUTOEXEC script (Lower Case).
if [ $IPADDRESS == exit ]; then

# Restart the Management system.	
	exec "$RPNAUTOEXECSCRIPT"
else

	
	echo "The Management system will now remove '$IPADDRESS' from SSH's known hosts!"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

	echo "Removing '$IPADDRESS' from known hosts..."
	sudo ssh-keygen -f "/home/pi/.ssh/known_hosts" -R $IPADDRESS &> /dev/null
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(SSH-KNOWNHOSTS):" "Management system attempted to remove ""'""$IPADDRESS""'"" as a known SSH host!" >> /home/pi/RPNSMS/eventlog.log
	printf "\n"

# Add the current user to access the known ssh hosts folder:
	sudo chown -v $CURRENTUSER ~/.ssh/known_hosts &> /dev/null
	
	echo "+ Reset SSH 'known_hosts' folders owner to user: $CURRENTUSER"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(SSH-KNOWNHOSTS):" "Management system reset SSH 'known hosts' folders owner to user: $CURRENTUSER." >> /home/pi/RPNSMS/eventlog.log

	echo -e "+${GREEN} [OK]${WHITE} Command sent to SSH on Management System '$IPADDRESS'"
	sleep 4s

# Restart Mass script.
	exec "$RPNAUTOEXECSCRIPT"

else
	exec "$RPNAUTOEXECSCRIPT"
fi	
fi
fi
		;;

		"Check for Updates")
# Update the Raspberry Pi Management System.

	echo "+---------------------------------------------------------------------------+"
	echo "Check for updates:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}The system will automatically download and install the latest"
	echo -e "${GREEN}version of the Management System. This will also update"	
	echo -e "${GREEN}& upgrade the Raspberry Pi OS and installed packages.${WHITE}"
	echo -e "Tasks which will be performed:"
	echo -e "* Update Raspberry Pi OS to the latest version."
	echo -e "* Download and install the latest version of the Management System." 
	echo -e "${WHITE}*${RED} Reboot the Management System.${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	read -p "Proceed with update? (yes/no) " yn

case $yn in 
# Open the 'eventlog' file as READ ONLY with a live TTY feed.
	yes ) MSUPDATE="1";;
# Open the 'eventlog' file as READ ONLY.
	no ) MSUPDATE="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $MSUPDATE -eq 1 ]; then

# Start the update process...
    echo -e "+${GREEN} [OK]${WHITE} Proceeding with update..."
	echo -e "+${RED} Do not exit this session or turn off the Management system!${WHITE}"

	printf "\n"

# Perform Raspberry Pi OS update. 
	echo "+ Updating Raspberry Pi OS... Do not turn off the system!"
    sudo apt-get $CMDACTIONS update > /dev/null
	UPDATERESULT=$?
	if [ $UPDATERESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Management system updated the Raspberry Pi OS." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} Update successful."

else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Management system failed to update the Raspberry Pi OS!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL] ${WHITE} Update failed!"
fi
	printf "\n"

# Perform Raspberry Pi OS upgrade. 
	echo "+ Upgrading Raspberry Pi OS... (This may take a while)"
	sudo apt-get -y upgrade > /dev/null
# Variable to contain command outcome.
	UPGRADERESULT=$?
	if [ $UPDATERESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Management system upgraded the Raspberry Pi OS." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Upgrade successful."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Management system failed to upgrade the Raspberry Pi OS." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL] ${WHITE} Upgrade failed!"
fi
	printf "\n"

	echo -e "+ [OK] The update & upgrade has been completed."

	printf "\n"

# GIT hub - Downloading the latest Management System

# Create TEMPUPDATE directory for update
 
	echo "+ Deleting existing update folder..."
	sudo rm -rf /home/pi/RPNSMS/TEMPUPDATE > /dev/null
	echo -e "+${GREEN} [OK]${WHITE} Attempted to delete update folder."

	printf "\n"
 
	echo "+ Creating update folder..."
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "Attempting to create temporary update folder." >> /home/pi/RPNSMS/eventlog.log
	sudo mkdir /home/pi/RPNSMS/TEMPUPDATE > /dev/null
	TEMPUPDATEDIR=$?

# Confirm the TEMPUPDATE folder has been created.
	if [ $TEMPUPDATEDIR -eq 0 ]; then
# Event log entry:
	printf "\n"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "Temporary update folder was created successfully." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Update folder created."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Failed to create temporary update folder, the folder may already exist. Check disk space and that the current user has sudo rights!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL] ${WHITE} Failed to create update folder! Folder might already exist."
fi	
		
	echo "+ Downloading the latest version of the Management System..."	
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "Attempting to download the latest version of the Management System." >> /home/pi/RPNSMS/eventlog.log
#   git clone $MSUPDATEURL /home/pi/RPNSMS/TEMPUPDATE
	sudo unzip -q -d /home/pi/RPNSMS/TEMPUPDATE /home/pi/RPNSMS/TEMPUPDATE.zip 
   gitupdatefetch=$?

# Confirm the TEMPUPDATE folder has been created.
	if [ $gitupdatefetch -eq 0 ]; then
# Event log entry:
	printf "\n"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "The update was successfully downloaded." >> /home/pi/RPNSMS/eventlog.log
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "Update URL:$MSUPDATEURL" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The update has been downloaded successfully."
else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Failed to download update! Check disk space, firewall access and sudo rights!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL] ${WHITE} Failed to download the update file!"
    echo -e "${WHITE} ! Check the Management System has free space,"
    echo -e "${WHITE} ! Confirm no firewall is blocking access to github."
    echo -e "${WHITE} ! Confirm the current user has sudo rights."
	echo -e "${RED} FATAL ERROR!${WHITE}"
	sleep 6s
# Restart Mass script.
	exec "$RPNAUTOEXECSCRIPT"
fi


# Show update and fixes

MSUPDATETXT=$(cat /home/pi/RPNSMS/TEMPUPDATE/ver.txt) 	# Location of the version file with CAT command.
MSUPDATETXTLOC="/home/pi/RPNSMS/TEMPUPDATE/ver.txt"		# Location of the version file.		
MSUPDATETXTVER=$(sed -n 1p $MSUPDATETXTLOC)				# Shows the version line. For logging.
	echo "+---------------------------------------------------------------------------+"
	echo "Patch notes:"
	echo "+---------------------------------------------------------------------------+"
	echo "$MSUPDATETXT"
	echo "+---------------------------------------------------------------------------+"
	printf "\n"
	echo -e "Press ${GREEN}ANY KEY ${WHITE}to begin the update."
	echo "+---------------------------------------------------------------------------+"
	read -e -p ""	

# Start the upgrade process:
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "Updating the Management System files..." >> /home/pi/RPNSMS/eventlog.log
#   git clone $MSUPDATEURL /home/pi/RPNSMS/TEMPUPDATE
	echo "+ Updating the Management System files..."
	echo -e "+${RED} Do not exit this session or turn off the Management system!${WHITE}"	
	sudo cp -R $MSUPDATELOC/* /home/pi/RPNSMS/
	MSUPDATECOPY=$?

# Update the .bashrc file.
	echo "+ Updating the Management System bash file..."
	sudo cp /home/pi/RPNSMS/TEMPUPDATE/.bashrc /home/pi
	BASHRCCOPYRESULT=$?

# Check if the folder copy was successful.
if [ $BASHRCCOPYRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "The Management System bash file has been updated." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} .bashrc file updated."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "The Management System bash file failed to copy!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} .bashrc file failed to copy!"
fi

# Confirm the update copy job completed:
	if [ $MSUPDATECOPY -eq 0 ]; then
# Event log entry:
	printf "\n"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-UPDATE):" "The Management System files have been updated." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} The Management System files have been updated."
	
# Set Management system scripts as executables.
	echo "+ Setting Management System scripts as executable..."
	sudo chmod u+x /home/pi/RPNSMS/NoticeScreenManagementSystem.bash
	sudo chmod u+x /home/pi/RPNSMS/autoexec.bash
	sudo chmod u+x /home/pi/RPNSMS/ASSETS/NoticeScreenManagementSystemMass.bash
	
# Set folder owners:
	sudo chown -R pi /home/pi/RPNSMS &> /dev/null


else
	printf "\n"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The Management System failed to update! FATAL ERROR!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL] ${WHITE} FATAL ERROR! The update failed! Please try the update process again!"
	echo -e "+${RED}! ${WHITE} A full rebuild might be required!"
fi

	printf "\n"

	
# Check for an active internet connection.
	echo "+ Checking for an active internet connection..."
	ping -c4 8.8.8.8 > /dev/null
if [ $? -eq 0 ]; then   
    echo -e "+${GREEN} [OK]${WHITE} Internet connection present!"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Internet connection present." >> /home/pi/RPNSMS/eventlog.log
	else
	echo -e "+${ORANGE} [WARN]${WHITE} Internet connection error!"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Internet connection error! (0x00002)" >> /home/pi/RPNSMS/eventlog.log
fi

# Check the eventlog exists. If not, create a new one:
if [ -e "$logfile" ]
then
# Event log entry:
    echo -e "+${GREEN} [OK]${WHITE} $logfile exists."
# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log &> /dev/null
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$logfile did not exist! A new log file has been created!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $logfile does not exist! Creating log file."	
# Ensure that the ownership of the event log file is set to pi.
	sudo chown pi /home/pi/RPNSMS/eventlog.log &> /dev/null
fi

# Check installed applications:
# Check SSHPASS is present:
sudo sshpass &> /dev/null
	SSHPASSRESULT=$?
	if [ $SSHPASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "SSHPASS PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} SSHPASS PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "SSHPASS FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} SSHPASS FAILED!"
fi

# Check GITHUB is present:
sudo git --version &> /dev/null
	GITPASSRESULT=$?
	if [ $GITPASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "GIT PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} GIT PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "GIT FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} GIT FAILED!"
fi

# Check APACHE2 is present:
sudo apache2 -v &> /dev/null
	APACHE2PASSRESULT=$?
	if [ $APACHE2PASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "APACHE2 PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} APACHE2 PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "APACHE2 FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} APACHE2 FAILED!"
fi

# File structures:

# autostartbak location:
if [ -e "$autostartbak" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostartbak exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $autostartbak exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostartbak does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $autostartbak does not exist!"
fi

# Music location:
if [ -e "$Music" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Music exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Music exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Music does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Music does not exist!"
fi

# Picturesbak location:
if [ -e "$Picturesbak" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Picturesbak exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Picturesbak exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Picturesbak does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Picturesbak does not exist!"
fi

# Pictures location:
if [ -e "$Pictures" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Pictures exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Pictures exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Pictures does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Pictures does not exist!"
fi

# Videos location:
if [ -e "$Video" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Video exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Video exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Video does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Video does not exist!"
fi

# autostart location:
if [ -e "$autostart" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostart exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $autostart exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostart does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $autostart does not exist!"
fi

# NoticeScreenMS location:
if [ -e "$NoticeScreenMS" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMS exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $NoticeScreenMS exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMS does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $NoticeScreenMS does not exist!"
fi

# NoticeScreenMSMASS location:
if [ -e "$NoticeScreenMSMASS" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMSMASS exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $NoticeScreenMSMASS exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMSMASS does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $NoticeScreenMSMASS"
    echo -e "  does not exist!"
fi

# Autoexec location:
if [ -e "$AutoexecLOC" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoexecLOC exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AutoexecLOC exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoexecLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AutoexecLOC"
    echo -e "  does not exist!"
fi

# Advanced MS Options location:
if [ -e "$AdvancedMSOptions" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AdvancedMSOptions exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AdvancedMSOptions exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AdvancedMSOptions does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AdvancedMSOptions"
    echo -e "  does not exist!"
fi

# AutoUpdate location:
if [ -e "$AutoUpdate" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoUpdate exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AutoUpdate exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoUpdate does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AutoUpdate"
    echo -e "  does not exist!"
fi


	printf "\n"

# Check if the essential command completed correctly.

if [ $SYSTEMINITSTATE -eq 14 ]; then

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The Management System has been updated successfully to: $MSUPDATETXTVER" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} Management system initialization PASSED!"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${WHITE}The Management System has successfully updated to: $MSUPDATETXTVER"
	echo -e "Press ${GREEN}ANY KEY ${WHITE}to restart the Management System."
	echo "+---------------------------------------------------------------------------+"
	read -e -p ""

# Perform system cleanup:
	echo "+ Removing temporary file used for the upgrade process..."	
	sudo rm -r /home/pi/RPNSMS/TEMPUPDATE
	sudo rm /home/pi/RPNSMS/ver.txt

# Reboot the Management System:
	echo "+ Restarting Management System ..."
    sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The management system was sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sudo shutdown -r now
	exit

else
		
	echo "+---------------------------------------------------------------------------+"
    echo -e "+${RED} [FAIL]${WHITE} The Management System update failed! FATAL ERROR!"
    echo -e "  Please check the eventlog file! A Rebuild may be required!"	
	echo "+---------------------------------------------------------------------------+"
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The Management System update failed! FATAL ERROR! A Rebuild may be required!" >> /home/pi/RPNSMS/eventlog.log
	sleep 4s
	
	# Reload Autoexec.
	exec "$RPNAUTOEXECSCRIPT"
fi

# Should the user answer no to updating:
	else
    echo -e "+${GREEN} [OK]${WHITE} No changes made."
		sleep 2s
# Reload Autoexec.
	exec "$RPNAUTOEXECSCRIPT"
	fi
		
            ;;	

# Perform a repair to the Management System:
        "Repair Management System")

	echo "+---------------------------------------------------------------------------+"
	echo "Repair Management System:"
	echo "+---------------------------------------------------------------------------+"
	echo -e "${GREEN}If there are problems with certain applications working, you can"
	echo -e "${GREEN}use this to reinstall all software used by the Management System."
	echo -e "${GREEN}The Management System will also reboot.${WHITE}"
	echo "+---------------------------------------------------------------------------+"
	read -p "Proceed? (yes/no) " yn

case $yn in 
# If the user types 'yes':
	yes ) YNOPTION="1";;
# If the user types 'no':
	no ) YNOPTION="0" && exec "$RPNAUTOEXECSCRIPT";
		exit;;
	* ) echo invalid response;
#		exit 1;;
esac

	printf "\n"

# Check if the user said yes or no to the update.
if [ $YNOPTION -eq 1 ]; then

# Repair SSHPASS.
	echo "+ Reinstalling SSHPASS..."
	sudo apt-get $CMDACTIONS install --reinstall sshpass > /dev/null
# Variable to contain command outcome.
	SSHPASSINSTALLRESULT=$?
if [ $SSHPASSINSTALLRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-Repair):" "SSHPASS reinstalled." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} SSHPASS reinstalled..."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-Repair):" "SSHPASS failed to install/uninstall!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} SSHPASS failed to install/uninstall."
fi
	printf "\n"

# Repair apache2.
	echo "+ Reinstalling apache2..."
	sudo apt-get $CMDACTIONS install --reinstall apache2 > /dev/null
# Variable to contain command outcome.
	APACHE2INSTALLRESULT=$?
if [ $APACHE2INSTALLRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-Repair):" "Apache2 reinstalled." >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${GREEN} [OK]${WHITE} apache2 reinstalled..."
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System-Repair):" "Apache2 failed to install/uninstall!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "!${RED} [FAIL]${WHITE} apache2 failed to install/uninstall."
fi
	printf "\n"

# Check installed applications:
echo "+ Checking Management System files..."

# Check SSHPASS is present:
sudo sshpass &> /dev/null
	SSHPASSRESULT=$?
	if [ $SSHPASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "SSHPASS PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} SSHPASS PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "SSHPASS FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} SSHPASS FAILED!"
fi

# Check GITHUB is present:
sudo git --version &> /dev/null
	GITPASSRESULT=$?
	if [ $GITPASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "GIT PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} GIT PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "GIT FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} GIT FAILED!"
fi

# Check APACHE2 is present:
sudo apache2 -v &> /dev/null
	APACHE2PASSRESULT=$?
	if [ $APACHE2PASSRESULT -eq 0 ]; then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "APACHE2 PASSED." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} APACHE2 PASSED."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
else
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "APACHE2 FAILED!" >> /home/pi/RPNSMS/eventlog.log
	echo -e "+${RED} [FAIL]${WHITE} APACHE2 FAILED!"
fi

# File structures:

# autostartbak location:
if [ -e "$autostartbak" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostartbak exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $autostartbak exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostartbak does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $autostartbak does not exist!"
fi

# Music location:
if [ -e "$Music" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Music exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Music exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Music does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Music does not exist!"
fi

# Picturesbak location:
if [ -e "$Picturesbak" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Picturesbak exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Picturesbak exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Picturesbak does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Picturesbak does not exist!"
fi

# Pictures location:
if [ -e "$Pictures" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Pictures exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Pictures exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Pictures does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Pictures does not exist!"
fi

# Videos location:
if [ -e "$Video" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Video exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $Video exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$Video does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $Video does not exist!"
fi

# autostart location:
if [ -e "$autostart" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostart exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $autostart exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$autostart does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $autostart does not exist!"
fi

# NoticeScreenMS location:
if [ -e "$NoticeScreenMS" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMS exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $NoticeScreenMS exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))
	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMS does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $NoticeScreenMS does not exist!"
fi

# NoticeScreenMSMASS location:
if [ -e "$NoticeScreenMSMASS" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMSMASS exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $NoticeScreenMSMASS exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$NoticeScreenMSMASS does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $NoticeScreenMSMASS"
    echo -e "  does not exist!"
fi

# Autoexec location:
if [ -e "$AutoexecLOC" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoexecLOC exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AutoexecLOC exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoexecLOC does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AutoexecLOC"
    echo -e "  does not exist!"
fi

# Advanced MS Options location:
if [ -e "$AdvancedMSOptions" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AdvancedMSOptions exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AdvancedMSOptions exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AdvancedMSOptions does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AdvancedMSOptions"
    echo -e "  does not exist!"
fi

# AutoUpdate location:
if [ -e "$AutoUpdate" ]
then
# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoUpdate exists." >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${GREEN} [OK]${WHITE} $AutoUpdate exists."
	((SYSTEMINITSTATE=SYSTEMINITSTATE+1))	
else
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "$AutoUpdate does not exist!" >> /home/pi/RPNSMS/eventlog.log
    echo -e "+${RED} [FAIL]${WHITE} $AutoUpdate"
    echo -e "  does not exist!"
fi


	printf "\n"

# Check if the essential command completed correctly.

if [ $SYSTEMINITSTATE -eq 14 ]; then

	echo -e "+${GREEN} [OK]${WHITE} Management system initialisation PASSED!"
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "Management system initialisation test passed." >> /home/pi/RPNSMS/eventlog.log
	else
    echo -e "+${RED} [FAIL] ${WHITE} One or more management system initialisation tests failed! Please check the eventlog file!"	
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "One or more management system initialisation tests failed!" >> /home/pi/RPNSMS/eventlog.log
fi

	printf "\n"

# After the repair has been completed, reboot the Raspberry Pi.
	echo -e "+ [OK] The repair has been completed. The Raspberry Pi will now reboot."

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The management system was sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	echo "+ Restarting Management System Pi..."
	sleep 4s

# Event log entry:
	sudo echo "$(date "+%D %T")" "$CURRENTHOSTIP""(Management-System):" "The management system was sent a restart command." >> /home/pi/RPNSMS/eventlog.log
	sudo shutdown -r now

else
	exec "$RPNAUTOEXECSCRIPT"
fi

            ;;	

        "View event logs")

	printf "\n"

# Check that the log file exists. This could be very suspicious if it's missing. 
if [ -f "$EVENTLOGFILELOC" ]; then  
	echo -e "${GREEN}Checking log file...${WHITE}"  

# Warn user to ensure the console session is the same length as the line below:
	echo "+---------------------------------------------------------------------------+"
	echo "When using live TTY, resize the console window to ensure updated"
	echo "entries fit correctly. This can be done with the live TTY running."
	echo "Close the console window, when finished with the live TTY."
	echo "Choosing 'no' will open the log file without live updates."
	echo "+---------------------------------------------------------------------------+"
	read -p "Open as a live TTY console? (yes/no) " yn

case $yn in 
# Open the 'eventlog' file as READ ONLY with a live TTY feed.
	yes ) clear && tail -f $EVENTLOGFILELOC && ./autoexec.bash;;
# Open the 'eventlog' file as READ ONLY.
	no ) sudo nano -view $EVENTLOGFILELOC && ./autoexec.bash;
		exit;;
	* ) echo invalid response;
		exec "$RPNAUTOEXECSCRIPT";;
esac

	else  
	echo -e "${RED}WARNING: Unable to open the event log. Is it missing? ${WHITE}"
	sleep 2s
# Reload Autoexec.
	exec "$RPNAUTOEXECSCRIPT"	
fi  	
            ;;			


        "Advanced options")

	exec "$NoticeScreenADV"	
 	

esac
done
